# Growlanzo dashboard screenshots (QA artifacts)

Captured from the real built application (`dist/`) served at **http://127.0.0.1:4175**, from this working tree (parent commit `fc50432`), on **26/10/2026 15:42–15:47 UTC**. Chromium 1243 headless, desktop 1440×900 unless noted.

This run re-captured the whole set **after the rebrand and the auth-resume change**, so every screen shows the final Growlanzo "G" logo and the final contact address (`growlanzo.own@gmail.com`).

Accounts are the repository's disposable E2E test accounts (`E2E Client`, `E2E Freelancer`) — fake identities. Demo data: one DEMO project (*E-commerce Store Redesign — DEMO*, ₹30,000) with one ₹28,000 contract in `pending` / escrow-unfunded state, shared by both dashboards so the two sides tell the same story.

| Filename | Role | Route | Test performed | Result | Viewport | Data type | Capture timestamp |
|---|---|---|---|---|---|---|---|
| `client_01_overview.png` | client | `/client` | Identity + stat cards + profile-completion meter render; project/contract/proposal cards match the DB | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:05 UTC |
| `client_02_post_project.png` | client | `/client/post` | Project form renders with the DEMO values (title, description, ₹30,000 budget, skills, duration) | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:12 UTC |
| `client_03_find_talent_matches.png` | client | `/client/matches?project_id=…` | AI match generated for the DEMO project; E2E Freelancer listed with the app's real match score | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:22 UTC |
| `client_04_received_proposals.png` | client | `/client/proposals` | Proposal from E2E Freelancer on the DEMO project (₹28,000 / 18 days) | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:29 UTC |
| `client_05_contracts.png` | client | `/client/contracts` | Contract from the accepted proposal; ₹28,000 shown, escrow not funded | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:38 UTC |
| `client_06_workspace_milestones.png` | client | `/client/workspace?contract=…` | Workspace opens for the DEMO contract: participants, chat, milestones/escrow tabs render | **PASS** (full page) | 1440×1386 | demo/test | 26/10/2026, 15:43:08 UTC |
| `client_07_payments_test_mode.png` | client | `/client/payments` | Payment surfaces render; no transaction executed (test mode unprovable) — view only | **PASS (view only)** | 1440×900 | demo/test | 26/10/2026, 15:42:47 UTC |
| `client_08_profile_settings.png` | client | `/client/settings` | Settings/profile surface renders with the client's saved data | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:42:54 UTC |
| `freelancer_01_overview.png` | freelancer | `/dashboard` | Freelancer identity, stat cards and activity; no client-only data | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:43:02 UTC |
| `freelancer_02_project_feed.png` | freelancer | `/dashboard/feed` | DEMO project in the matched feed with correct budget/skills | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:43:15 UTC |
| `freelancer_03_proposals.png` | freelancer | `/dashboard/proposals` (Hired tab) | The accepted proposal is listed under **Hired** — same project/amount as the client's view | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:43:24 UTC |
| `freelancer_04_profile.png` | freelancer | `/dashboard/profile` | Title/bio/rate/skills persisted (saved earlier through the UI, re-read after reload) | **PASS** (full page) | 1440×1145 | demo/test | 26/10/2026, 15:43:33 UTC |
| `freelancer_05_portfolio.png` | freelancer | `/dashboard/portfolio` | Portfolio surface renders (empty state — no fabricated projects) | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:43:44 UTC |
| `freelancer_06_contracts.png` | freelancer | `/dashboard/contracts` | Same contract visible to the freelancer; ₹28,000, escrow unfunded | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:43:52 UTC |
| `freelancer_07_workspace_milestones.png` | freelancer | `/dashboard/workspace?contract=…` | Same workspace from the freelancer side; role-scoped, same milestones | **PASS** (full page) | 1440×1307 | demo/test | 26/10/2026, 15:43:21 UTC |
| `freelancer_08_wallet_test_data.png` | freelancer | `/dashboard/wallet` | Wallet balances render and reconcile with the unfunded escrow (₹0 available/pending) | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:44:00 UTC |
| `freelancer_09_invites.png` | freelancer | `/dashboard/invites` | Invites surface renders (0 pending) for this freelancer only | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:44:07 UTC |
| `freelancer_10_notifications.png` | freelancer | `/dashboard/notifications` | Notifications correspond to the real demo events (match / proposal / contract) | **PASS** | 1440×900 | demo/test | 26/10/2026, 15:44:14 UTC |
| `shared_01_mobile_client_dashboard.png` | client | `/client` | Mobile overview renders without overflow | **PASS** | 390×844 | demo/test | 26/10/2026, 15:44:21 UTC |
| `shared_02_mobile_freelancer_dashboard.png` | freelancer | `/dashboard` | Mobile overview renders without overflow | **PASS** | 390×844 | demo/test | 26/10/2026, 15:44:30 UTC |
| `shared_03_header_logo_v2.png` | — | `/` (logged out) | Public header with the final logo, wordmark and nav (no modal over it) | **PASS** | 1440×150 | public | 26/10/2026, 15:46:58 UTC |
| `shared_04_homepage_hero.png` | — | `/` (logged out) | Public homepage hero — the first thing a visitor sees, with the final logo | **PASS** | 1440×900 | public | 26/10/2026, 15:46:59 UTC |

## Notes

- Demo/test data is **not** evidence of real users, real customer projects, real payments or completed identity verification.
- No payment, payout or refund was executed. Escrow stayed at ₹0 and the contract shows *pending / not funded*; the payment step is BLOCKED in the report.
- A signed-in visitor is no longer asked to sign in again: `/?modal=login` and `/?modal=signup` now resume the persisted session straight into the role dashboard (verified in this run for both roles; see TEST_REPORT.md §4).
- Screenshots are QA artifacts. They are **not** part of the deployment bundle (`dist/` is built from `public/` + `src/`), and the image files are not tracked by git — see the note in TEST_REPORT.md.
- Identity verification is deferred in this build; no verification badge is claimed anywhere.
