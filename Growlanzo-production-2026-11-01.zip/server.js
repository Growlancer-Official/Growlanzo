/* eslint-env node */
import express from 'express';
import { fileURLToPath } from 'url';
import path, { dirname, join } from 'path';
import fs from 'fs';
import compression from 'compression';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 4173;
const DIST_DIR = join(__dirname, 'dist');

// Enable compression
app.use(compression());

// ─── Security headers (pre-deploy production audit) ───
// Applied to every response so browsers enforce nosniff, frame protection,
// HSTS, and a baseline CSP even before the SPA's own <meta> tags.
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  // HSTS only over HTTPS (Vercel terminates TLS, so this is safe there;
  // plain-HTTP local dev is unaffected since the header is inert without TLS)
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  res.setHeader(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=(), payment=()'
  );
  // Baseline CSP: Vite dev server injects inline scripts/styles, so keep
  // 'unsafe-inline' for style and allow self + Razorpay/PayPal scripts.
  // Typography: Fontshare only (api.fontshare.com serves the CSS,
  // cdn.fontshare.com serves the actual woff2). Both are loaded via <link> in
  // pages/+Head.tsx, so they must be allowed in style-src/font-src or the
  // typography silently breaks. The former Google Fonts entries were removed
  // after the Inter load was dropped: nothing in the build requests
  // fonts.googleapis.com / fonts.gstatic.com any more, and an allow-list entry
  // with no requester is pure attack surface. Must stay in sync with
  // vercel.json, which carries the production header.
  // Supabase realtime uses wss:// so connect-src includes wss://*.supabase.co.
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; " +
      "script-src 'self' 'unsafe-inline' https://checkout.razorpay.com https://*.paypal.com https://*.paypalobjects.com; " +
      "style-src 'self' 'unsafe-inline' https://api.fontshare.com; " +
      "img-src 'self' data: blob: https:; " +
      "font-src 'self' data: https://api.fontshare.com https://cdn.fontshare.com; " +
      "connect-src 'self' https://*.supabase.co wss://*.supabase.co https://*.paypal.com https://api.razorpay.com https://checkout.razorpay.com https://api.fontshare.com https://cdn.fontshare.com https://o4511722119495680.ingest.us.sentry.io; " +
      "frame-src 'self' https://checkout.razorpay.com https://*.paypal.com; " +
      "media-src 'self' blob:; " +
      "object-src 'none'; base-uri 'self'; form-action 'self'"
  );
  next();
});

// Serve static files from dist directory
app.use(express.static(DIST_DIR, {
  maxAge: '1d', // Cache static assets for 1 day
  etag: false,
}));

// Health check endpoint
app.get('/_health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// SPA fallback: route all non-file requests to index.html
app.use((req, res) => {
  // Don't fallback for API routes or specific file types
  if (req.path.startsWith('/api/') || /\.\w+$/.test(req.path)) {
    return res.status(404).json({ error: 'Not found' });
  }

  // SPA routing — same semantics as Vercel's static-first fallback:
  // serve the PRERENDERED page for its URL (correct title/canonical/SSR
  // content), then fall back to index.html only for truly client-only
  // routes (dashboard, onboarding, dynamic public pages…).
  // NOTE: Vike prerenders to dist/client/<route>/index.html; dist/ mirrors
  // dist/client/ (see vercelOutputWorkaroundPlugin in vite.config.ts), so a
  // plain sendFile would path-traverse — always resolve via dist/client/.
  const safePath = path.posix.normalize(req.path).replace(/^([.][.][/\\])+/, '');
  const prerendered = join(DIST_DIR, 'client', safePath, 'index.html');
  if (
    !safePath.includes('..') &&
    safePath !== '/' &&
    fs.existsSync(prerendered) &&
    fs.statSync(prerendered).isFile()
  ) {
    return res.sendFile(prerendered, (err) => {
      if (err && !res.headersSent) {
        res.status(500).json({ error: 'Internal server error' });
      }
    });
  }

  // Client-only route: serve the app shell (boot splash covers the
  // homepage-HTML flash; #root is cleared pre-hydration so React does a
  // clean client render — see BOOT_SPLASH_HTML in vite.config.ts).
  res.sendFile(join(DIST_DIR, 'index.html'), (err) => {
    if (err) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });
});

// Error handling middleware
app.use((err, req, res, _next) => {
  console.error('Server error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✓ Server running at http://0.0.0.0:${PORT}`);
  console.log(`✓ Serving SPA from ${DIST_DIR}`);
  console.log(`✓ SPA routing enabled - all routes fallback to index.html`);
});
