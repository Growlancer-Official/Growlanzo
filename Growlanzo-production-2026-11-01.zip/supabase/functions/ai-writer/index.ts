import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.7';
import { AI_API_KEY, callAI } from '../_shared/ai.ts';
import { getCorsHeaders } from '../_shared/cors.ts'

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// ─── Growlanzo AI Writer ────────────────────────────────────────────────────
// Generates professional text (project title, project description, cover
// letter, service title/description) from a short "what do you want" input.
// - Requires an authenticated user (JWT)
// - Per-user DAILY allowance (freelancer writing): Free = 5/day, Pro = 100/day
// - CLIENT fields (project_title / project_description) are FREE for life per
//   the business model — they only get a generous fair-use abuse guard with a
//   NEUTRAL message (never "upgrade"), because clients must never see a paywall.
// - Rate limit data lives in the `rate_limits` table (window_start = UTC day)
// - AI key is read from secrets only — never exposed to the frontend

const FREE_DAILY_LIMIT = 5; // freelancer fields (service_*, cover_letter)
const PRO_DAILY_LIMIT = 100; // freelancer fields, Pro
const CLIENT_FAIR_USE_DAILY_LIMIT = 100; // client fields — abuse guard only
// One universal number for every AI writer surface (client fair-use guard and
// the Pro allowance), and it is NEVER rendered as a counter on a client
// surface: the client AI promise is "free for life", so the cap exists purely
// to stop abuse and its message stays neutral (see the 429 branch below).
const ROUTE = 'ai-writer';
const MAX_INPUT_LEN = 2000;


const FIELDS = [
  'project_title',
  'project_description',
  'cover_letter',
  'service_title',
  'service_description',
] as const;
type Field = (typeof FIELDS)[number];

// Fields a CLIENT uses when posting a project → free for life (fair-use guard
// only, never monetized, never an upgrade prompt).
const CLIENT_FIELDS = new Set<Field>(['project_title', 'project_description']);

interface WriterContext {
  budget?: number | string;
  category?: string;
  industry?: string;
  skills?: string[];
  deadline?: string;
  experience_level?: string;
  project_title?: string;
  project_description?: string;
  base_price?: number | string;
  extra_revision_price?: number | string;
  user_name?: string;
  freelancer_skills?: string[];
}

/** Field → (system prompt, what the model must return). */
function buildPrompt(field: Field, input: string, context: WriterContext = {}): { system: string; user: string } {
  const skills = Array.isArray(context.skills) && context.skills.length > 0
    ? context.skills.join(', ')
    : Array.isArray(context.freelancer_skills) && context.freelancer_skills.length > 0
      ? context.freelancer_skills.join(', ')
      : '';

  const commonRules = [
    'Respond in the SAME language the user wrote in (English, Hindi, Hinglish, etc.).',
    'Be professional, specific and concrete — never vague filler.',
    'Use plain text only — no markdown headers, no asterisks, no bullet symbols (use "- " only if a list is natural).',
    'Never invent facts (budgets, dates, features) that the user did not mention.',
    'Output ONLY the final text — no explanations, no preamble, no quotes around the whole thing.',
  ].join('\n');

  let system = '';
  let user = '';

  switch (field) {
    case 'project_title': {
      system = [
        'You are Growlanzo AI, an expert at writing project titles for a freelancing marketplace.',
        'Write ONE catchy, professional, keyword-rich project title (max 80 characters).',
        'Make it instantly clear what the client wants to build.',
        'Do not use quotes, trailing punctuation or emojis.',
        commonRules,
      ].join('\n');
      user = `Here is what the client wants (write the title for this):\n"${input}"`;
      break;
    }
    case 'project_description': {
      system = [
        'You are Growlanzo AI, an expert at writing project descriptions for a freelancing marketplace.',
        'Write a clear, professional project description (3-6 short paragraphs) that freelancers can immediately understand and bid on.',
        'Cover: the goal/what to build, key requirements and deliverables, any specific skills needed, and a short closing line inviting proposals.',
        'Keep it concise — a freelancer should grasp the whole scope in under 30 seconds.',
        commonRules,
      ].join('\n');
      user = `Here is what the client wants (write the description for this):\n"${input}"`;
      break;
    }
    case 'cover_letter': {
      system = [
        'You are Growlanzo AI, an expert freelance proposal writer.',
        'Write ONE persuasive, professional cover message (2-4 short paragraphs) that a freelancer sends to a client when applying for a project.',
        'Make it personal and confident: quickly show understanding of the project, mention how the freelancer is a great fit, and end with a clear, friendly call to action.',
        'Never over-promise or invent skills the freelancer does not have.',
        commonRules,
      ].join('\n');
      user = `Write the cover message for this project:\nProject: ${context.project_title || 'N/A'}\nClient wants: ${context.project_description || input}\n\nFreelancer skills: ${skills || 'not provided'}\nBudget: ${context.budget ? `₹${context.budget}` : 'not specified'}`;
      break;
    }
    case 'service_title': {
      system = [
        'You are Growlanzo AI, an expert at writing service titles for freelancers on a marketplace.',
        'Write ONE catchy, professional, keyword-rich service title (max 80 characters) starting with "I will" (e.g. "I will design a modern logo for your brand").',
        'Make it clear what the freelancer delivers and for whom.',
        'Do not use quotes, trailing punctuation or emojis.',
        commonRules,
      ].join('\n');
      user = `Here is what the freelancer offers (write the service title for this):\n"${input}"`;
      break;
    }
    case 'service_description': {
      system = [
        'You are Growlanzo AI, an expert at writing service descriptions for freelancers on a marketplace.',
        'Write a clear, professional service description (3-5 short paragraphs) that makes clients want to buy.',
        'Cover: what the freelancer delivers, what the client will receive (the outcome), how the freelancer works, and a short closing line inviting the client to place an order.',
        'Keep it concise and benefit-focused.',
        commonRules,
      ].join('\n');
      user = `Here is what the freelancer offers (write the service description for this):\n"${input}"`;
      break;
    }
  }

  return { system, user };
}

/** Start-of-today (UTC) timestamp — the daily usage window. */
function todayStart(): string {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  return start.toISOString();
}

Deno.serve(async (req: Request) => {
  const origin = req.headers.get('origin');
  const corsHeaders = getCorsHeaders(origin);
  const json = (status: number, payload: Record<string, unknown>) =>
    new Response(JSON.stringify(payload), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  // Fail closed: refuse when the AI key is not configured
  if (!AI_API_KEY) {
    return json(500, { error: 'AI service is not configured' });
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // ─── AUTHENTICATION (JWT required) ───
    const anonClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY') ?? '', {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: { user: authUser }, error: authError } = await anonClient.auth.getUser();
    if (authError || !authUser) {
      return json(401, { error: 'Unauthorized' });
    }
    const user_id = authUser.id;

    // ─── BODY ───
    let body: { field?: string; input?: string; context?: WriterContext };
    try {
      body = await req.json();
    } catch {
      return json(400, { error: 'Invalid JSON body' });
    }

    const field = body?.field as Field | undefined;
    const input = (body?.input ?? '').trim();
    const context = body?.context ?? {};

    if (!field || !FIELDS.includes(field)) {
      return json(400, { error: 'Missing or invalid field. Allowed: ' + FIELDS.join(', ') });
    }
    if (!input) {
      return json(400, { error: 'Please describe what you want to generate.' });
    }
    if (input.length > MAX_INPUT_LEN) {
      return json(400, { error: `Input too long (max ${MAX_INPUT_LEN} characters).` });
    }

    // ─── PRO STATUS + ROLE (server-side; is_pro kept honest by trigger) ───
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_pro, role')
      .eq('id', user_id)
      .maybeSingle();
    const isPro = !!profile?.is_pro;
    const role = profile?.role ?? 'freelancer';

    // Client AI features are FREE FOR LIFE (platform promise). Project fields
    // only get a generous fair-use abuse guard with neutral messaging — never
    // a monetized 5/day cap, never an "upgrade" prompt. Freelancer fields
    // (service title/description, cover letter) keep the 5/day ↔ Pro model.
    const clientFree = role === 'client' || CLIENT_FIELDS.has(field);
    const limit = clientFree
      ? CLIENT_FAIR_USE_DAILY_LIMIT
      : isPro
        ? PRO_DAILY_LIMIT
        : FREE_DAILY_LIMIT;

    // ─── DAILY USAGE (rate_limits, window = UTC day) ───
    // Read the accumulated `count` column — NOT the row count. rate_limits has
    // UNIQUE (identifier, route, window_start), so there is exactly ONE row
    // per user/route/day; counting rows always yields ≤ 1, which is how the
    // old check could never fire (the cap was decorative).
    const windowStart = todayStart();
    try {
      await supabase.rpc('cleanup_expired_rate_limits');
    } catch {
      // Non-critical
    }
    const { data: usageRow, error: countError } = await supabase
      .from('rate_limits')
      .select('count')
      .eq('identifier', user_id)
      .eq('route', ROUTE)
      .gte('window_start', windowStart)
      .maybeSingle();

    const used = Number(usageRow?.count ?? 0);
    if (!countError && used >= limit) {
      return json(429, {
        error: clientFree ? 'fair_use_limit_reached' : 'daily_limit_reached',
        message: clientFree
          ? 'You have used a lot of AI today. Please try again in a little while.'
          : isPro
            ? 'Daily AI writing limit reached. Please try again tomorrow.'
            : `You have used all ${FREE_DAILY_LIMIT} free AI generations today. Upgrade to Pro for ${PRO_DAILY_LIMIT} AI writes per day.`,
        isPro,
        used,
        limit,
        freeForClients: clientFree,
      });
    }

    // Atomic increment via the server-only SECURITY DEFINER RPC. The old
    // `{ count: 1 }` upsert RESET the counter to 1 on every generation
    // (unique key above), so nothing ever accumulated and `used >= limit`
    // could never be true. increment_rate_limit does count = count + 1 and
    // returns the new value; if it ever fails, log LOUDLY and degrade to the
    // pre-increment estimate rather than silently skipping accounting.
    const { data: incrementedCount, error: incrementError } = await supabase
      .rpc('increment_rate_limit', {
        p_identifier: user_id,
        p_route: ROUTE,
        p_window_start: windowStart,
      });
    if (incrementError) {
      console.error('[ai-writer] usage increment failed:', incrementError.message);
    }
    const usedAfter = typeof incrementedCount === 'number'
      ? incrementedCount
      : used + 1;

    // ─── GENERATE ───
    const { system, user } = buildPrompt(field, input, context);
    const response = await callAI(
      [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      { maxTokens: 1500 }
    );

    if (!response.ok) {
      console.error('[ai-writer] AI call failed:', response.status, await response.text().catch(() => ''));
      return json(502, { error: 'AI generation failed. Please try again.' });
    }

    const data = await response.json();
    const text = (data?.choices?.[0]?.message?.content ?? '').trim();
    if (!text) {
      return json(502, { error: 'AI returned an empty response. Please try again.' });
    }

    return json(200, { success: true, text, isPro, used: usedAfter, limit, remaining: Math.max(0, limit - usedAfter), freeForClients: clientFree });
  } catch (err) {
    console.error('[ai-writer] unexpected error:', err?.message || err);
    return json(500, { error: 'Something went wrong. Please try again.' });
  }
});
