// Withdrawal Edge Function
// Handles withdrawal requests and processes actual payout API calls:
//   - RazorpayX Payouts (India, INR) via POST /v1/payouts
//   - PayPal Payouts (international, USD) via POST /v1/payments/payouts
// With full rollback on failure and provider payout ID tracking.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { getCorsHeaders } from '../_shared/cors.ts';
import { SITE_URL } from '../_shared/site.ts'

const RAZORPAY_KEY_ID = Deno.env.get('RAZORPAY_KEY_ID') || '';
const RAZORPAY_KEY_SECRET = Deno.env.get('RAZORPAY_KEY_SECRET') || '';
const RAZORPAY_ACCOUNT_NUMBER = Deno.env.get('RAZORPAY_ACCOUNT_NUMBER') || '';
const RAZORPAY_API_URL = 'https://api.razorpay.com/v1';

const PAYPAL_CLIENT_ID = Deno.env.get('PAYPAL_CLIENT_ID') || '';
const PAYPAL_CLIENT_SECRET = Deno.env.get('PAYPAL_CLIENT_SECRET') || '';
const PAYPAL_API_URL = Deno.env.get('PAYPAL_SANDBOX') === 'true'
  ? 'https://api-m.sandbox.paypal.com'
  : 'https://api-m.paypal.com';

// ─── Email Notification Helper (Brevo) ──────────────────────────────────────
import { sendEmail } from '../_shared/brevo.ts';

const APP_URL = SITE_URL;

// Service-role client: transactions is a server-audited ledger (no user INSERT/
// UPDATE RLS policies) — the withdrawal audit record must be written here.
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

async function finalizeProviderWithdrawal(
  withdrawalId: string,
  providerPayoutId: string,
  status: 'completed' | 'failed',
  failureReason?: string,
): Promise<void> {
  const result = status === 'completed'
    ? await supabaseAdmin.rpc('process_withdrawal_complete', { p_withdrawal_id: withdrawalId })
    : await supabaseAdmin.rpc('process_withdrawal_failure', {
      p_withdrawal_id: withdrawalId,
      p_failure_reason: failureReason || 'Payout failed at provider',
    });

  if (result.error || !result.data?.success) {
    throw new Error(`Provider payout ${providerPayoutId} was ${status}, but withdrawal finalization failed; reconciliation required`);
  }
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2 }).format(amount);
}

/** Send a transactional email via Brevo (no-op + logged when key missing). */
async function sendNotificationEmail(
  to: string,
  toName: string,
  subject: string,
  htmlContent: string
): Promise<void> {
  void toName;
  await sendEmail({ to, subject, html: htmlContent });
}

function buildWithdrawalEmail(name: string, amount: number, netAmount: number, method: string, status: 'completed' | 'failed', reason?: string): string {
  const isSuccess = status === 'completed';
  return `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; padding: 40px 20px; margin: 0;">
  <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
    <div style="background: linear-gradient(135deg, ${isSuccess ? '#14861f 0%, #0f6f1a' : '#dc2626 0%, #b91c1c'} 100%); padding: 32px; text-align: center;">
      <h1 style="color: white; font-size: 22px; font-weight: 700; margin: 0;">${isSuccess ? 'Withdrawal Processed ✅' : 'Withdrawal Failed 💔'}</h1>
    </div>
    <div style="padding: 32px;">
      <p style="font-size: 15px; color: #0f172a; line-height: 1.7;">Hi ${name.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')},</p>
      ${isSuccess
        ? `<p style="font-size: 15px; color: #0f172a; line-height: 1.7;">Your withdrawal of <strong style="color: #14861f;">${formatCurrency(amount)}</strong> has been processed successfully!</p>
           <div style="margin: 28px 0; padding: 20px; background: #f1fcef; border: 1px solid #bbefb4; border-radius: 12px;">
             <p style="font-size: 14px; color: #10591a; margin: 0;"><strong>Amount:</strong> ${formatCurrency(amount)}<br/><strong>Net Received:</strong> ${formatCurrency(netAmount)}<br/><strong>Method:</strong> ${method}</p>
           </div>
           <p style="font-size: 14px; color: #64748b; line-height: 1.7;">Funds should appear in 1-3 business days.</p>`
        : `<p style="font-size: 15px; color: #0f172a; line-height: 1.7;">Your withdrawal of <strong style="color: #dc2626;">${formatCurrency(amount)}</strong> could not be processed.</p>
           <div style="margin: 28px 0; padding: 20px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px;">
             <p style="font-size: 14px; color: #991b1b; margin: 0;">${reason ? reason.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') : 'An unexpected error occurred.'}</p>
           </div>
           <p style="font-size: 14px; color: #64748b; line-height: 1.7;">The full amount has been returned to your wallet.</p>`
      }
      <div style="margin: 24px 0; text-align: center;">
        <a href="${APP_URL}/dashboard/wallet" style="display: inline-block; padding: 12px 32px; background: #14861f; color: white; text-decoration: none; border-radius: 10px; font-weight: 600; font-size: 14px;">View Wallet →</a>
      </div>
      <p style="font-size: 14px; color: #64748b; line-height: 1.7;">— The Growlanzo Team</p>
    </div>
    <div style="padding: 24px 32px; background: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center;">
      <p style="color: #94a3b8; font-size: 12px; margin: 0;">Growlanzo — AI-Powered Freelancing Marketplace</p>
    </div>
  </div>
</body>
</html>`;
}

// ─── Payout API Helpers ───────────────────────────────────────────────────────

function getRazorpayBasicAuth(): string {
  return `Basic ${btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`)}`;
}

async function razorpayFetch(path: string, options: RequestInit = {}): Promise<any> {
  const response = await fetch(`${RAZORPAY_API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: getRazorpayBasicAuth(),
      ...(options.headers || {}),
    },
  });
  const body = await response.text();
  if (!response.ok) {
    let errorMsg = `Razorpay API error (${response.status})`;
    try { const err = JSON.parse(body); errorMsg = err.error?.description || err.error?.reason || errorMsg; } catch { /* ignore */ }
    throw new Error(errorMsg);
  }
  return JSON.parse(body);
}

async function getPayPalAccessToken(): Promise<string> {
  const authHeader = `Basic ${btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`)}`;
  const res = await fetch(`${PAYPAL_API_URL}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Accept: 'application/json', Authorization: authHeader, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new Error(`PayPal OAuth error: ${await res.text()}`);
  const data = await res.json();
  return data.access_token;
}

async function paypalFetch(path: string, options: RequestInit = {}): Promise<any> {
  const token = await getPayPalAccessToken();
  const response = await fetch(`${PAYPAL_API_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...(options.headers || {}) },
  });
  const body = await response.text();
  if (!response.ok) {
    let errorMsg = `PayPal API error (${response.status})`;
    try { const err = JSON.parse(body); errorMsg = err.message || err.error_description || err.name || errorMsg; } catch { /* ignore */ }
    throw new Error(errorMsg);
  }
  return JSON.parse(body);
}

async function rollbackWithdrawal(withdrawalId: string, userId: string, amount: number, errorReason: string): Promise<void> {
  console.error(`[ROLLBACK] Withdrawal ${withdrawalId} failed: ${errorReason}`, { userId, amount });
  // Wallet, withdrawal, and transaction state must roll back together. This
  // service-role-only RPC locks the rows and validates the held amount before
  // returning funds, then marks the withdrawal/ledger failed atomically.
  const { data, error } = await supabaseAdmin.rpc('process_withdrawal_failure', {
    p_withdrawal_id: withdrawalId,
    p_failure_reason: errorReason,
  });
  if (error || !data?.success) {
    console.error(`[ROLLBACK] Atomic withdrawal finalization failed for ${withdrawalId}; reconciliation required`, error?.message || data?.error);
    throw new Error(`Withdrawal ${withdrawalId} could not be rolled back atomically; reconciliation required`);
  }
}

// ─── Rate Limiting ───────────────────────────────────────────────────────────

const RATE_LIMIT = 10;
const RATE_WINDOW_MS = 3600000;
const ROUTE = 'withdrawal';

async function checkRateLimit(supabaseAdminClient: any, identifier: string): Promise<boolean> {
  const now = new Date();
  const windowStart = new Date(Math.floor(now.getTime() / RATE_WINDOW_MS) * RATE_WINDOW_MS);

  try {
    const { data, error } = await supabaseAdminClient.rpc('increment_rate_limit', {
      p_identifier: identifier,
      p_route: ROUTE,
      p_window_start: windowStart.toISOString(),
    });
    if (error || typeof data !== 'number') {
      console.error('Rate limiter unavailable — refusing the request (fail closed):', error?.message || 'invalid counter response');
      return false;
    }
    return data <= RATE_LIMIT;
  } catch (error) {
    console.error('Rate limiter unavailable — refusing the request (fail closed):', error);
    return false;
  }
}

Deno.serve(async (req) => {
  const origin = req.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization') ?? '' },
        },
      }
    )

    // Get user from auth
    const {
      data: { user },
      error: userError,
    } = await supabaseClient.auth.getUser()

    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }
    // Check rate limit (DB-backed, using user ID as identifier)
    const clientIP = req.headers.get('x-forwarded-for') || 'unknown';
    const identifier = user.id || clientIP;
    const allowed = await checkRateLimit(supabaseAdmin, identifier);
    if (!allowed) {
      return new Response(JSON.stringify({ error: 'Too many withdrawal requests. Please try again later.' }), {
        status: 429,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { method } = req

    if (method === 'POST') {
      const body = await req.json()
      const { amount, withdrawal_method, paypal_email, fund_account_id, payout_mode, payout_method_id } = body

      if (!amount || amount <= 0) {
        return new Response(JSON.stringify({ error: 'Invalid amount' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      const wdMethod = withdrawal_method || 'razorpay_payout'

      // 🛡️ SECURITY (2026): PayPal payouts are BLOCKED server-side until a real
      // INR→USD FX conversion is implemented. The wallet holds INR; the PayPal
      // payout API call below would otherwise send the INR amount labelled as
      // USD — a ~80× fund-drain (₹5,000 wallet → $4,855 payout). PayPal remains
      // disabled in the UI (VITE_PAYPAL_ENABLED=false); this guard makes sure no
      // direct API caller can reach the broken path either.
      if (wdMethod === 'paypal') {
        return new Response(JSON.stringify({ error: 'PayPal withdrawals are temporarily disabled. Please use Razorpay payout (UPI / bank transfer) instead.' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      if (wdMethod === 'paypal' && !paypal_email) {
        return new Response(JSON.stringify({ error: 'PayPal email is required' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      // ── Resolve the RazorpayX fund account SERVER-SIDE ─────────────────
      // Never trust a client-supplied fund_account_id. Look up the user's payout
      // method and use the stored razorpay_fund_account_id (created via the
      // `create_fund_account` action). Legacy raw IDs are still accepted for
      // backward compatibility but are validated against the user's own methods.
      let resolvedFundAccountId = fund_account_id || ''
      if (wdMethod === 'razorpay_payout') {
        if (payout_method_id) {
          const { data: pm } = await supabaseClient
            .from('payout_methods')
            .select('*')
            .eq('id', payout_method_id)
            .eq('user_id', user.id)
            .maybeSingle()
          if (!pm) {
            return new Response(JSON.stringify({ error: 'Payout method not found' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
          }
          if (pm.razorpay_fund_account_id) {
            resolvedFundAccountId = pm.razorpay_fund_account_id
          } else if (pm.upi_id) {
            // UPI fallback: the raw VPA is acceptable for RazorpayX vpa payouts.
            resolvedFundAccountId = pm.upi_id
          }
        }
        if (!resolvedFundAccountId) {
          return new Response(JSON.stringify({ error: 'Fund account ID is required. Link this payout method to RazorpayX first.' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
        }
      }

      const { data: walletData, error: walletError } = await supabaseClient.rpc('get_wallet_balance', { p_user_id: user.id })
      if (walletError) throw walletError
      const balance = walletData?.balance ?? 0
      const pendingBalance = walletData?.pending_balance ?? 0
      const availableBalance = balance - pendingBalance

      if (availableBalance < amount) {
        return new Response(JSON.stringify({ error: 'Insufficient balance', available_balance: availableBalance, requested_amount: amount }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      const feeRate = wdMethod === 'razorpay_payout' ? 0.02 : 0.029
      const fee = Math.round(amount * feeRate)
      const netAmount = Math.round(amount * (1 - feeRate))

      // Create withdrawal record
      const insertData: Record<string, any> = { user_id: user.id, amount, method: wdMethod, status: 'pending', fee, net_amount: netAmount, payout_mode: payout_mode || null }
      if (wdMethod === 'paypal') insertData.paypal_email = paypal_email
      if (wdMethod === 'razorpay_payout') insertData.razorpay_fund_account_id = resolvedFundAccountId

      const { data: withdrawal, error: withdrawalError } = await supabaseAdmin.from('withdrawals').insert(insertData).select().single()
      if (withdrawalError) throw withdrawalError

      // Hold wallet funds — service-role client, and p_user_id comes from the
      // verified session (never from the request body).
      const { data: holdResult, error: holdError } = await supabaseAdmin.rpc('hold_wallet_funds', { p_user_id: user.id, p_amount: amount })
      if (holdError || !holdResult?.success) {
        await supabaseAdmin.from('withdrawals').delete().eq('id', withdrawal.id)
        throw new Error(holdResult?.error || 'Failed to hold funds')
      }

      // Create transaction record (service-role — transactions is a server-audited
      // ledger; users have no INSERT/UPDATE policy on it)
      const txDesc = wdMethod === 'paypal' ? `Withdrawal to PayPal (${paypal_email})` : 'Withdrawal via Razorpay Payout'
      await supabaseAdmin.from('transactions').insert({
        user_id: user.id, amount, type: 'debit', source: 'withdrawal', status: 'pending', description: txDesc,
        metadata: { withdrawal_id: withdrawal.id, method: wdMethod },
      })

      // ────────────────────────────────────────────────────────────────────
      // ACTUAL PAYOUT API CALL
      // ────────────────────────────────────────────────────────────────────
      let providerPayoutId: string | null = null
      let payoutStatus = 'processing'

      try {
        if (wdMethod === 'razorpay_payout') {
          // ── RazorpayX Payouts API: POST /v1/payouts ──
          const mode = payout_mode || 'UPI'
          const payoutResult = await razorpayFetch('/payouts', {
            method: 'POST',
            body: JSON.stringify({
              account_number: RAZORPAY_ACCOUNT_NUMBER,
              fund_account_id: resolvedFundAccountId,
              amount: Math.round(amount * 100), // Convert to paise
              currency: 'INR',
              mode,
              purpose: 'payout',
              queue_if_low_balance: true,
              reference_id: `wd_${withdrawal.id.slice(0, 12)}`,
              narration: `Growlanzo Withdrawal - ${user.email || user.id.slice(0, 8)}`,
            }),
          })

          providerPayoutId = payoutResult.id
          const rpStatus = payoutResult.status
          if (rpStatus === 'processed' || rpStatus === 'completed') payoutStatus = 'completed'
          else if (rpStatus === 'failed' || rpStatus === 'cancelled') payoutStatus = 'failed'
          else payoutStatus = 'processing'

          const { error: payoutStateError } = await supabaseAdmin.from('withdrawals').update({
            razorpay_payout_id: providerPayoutId,
            status: payoutStatus === 'completed' || payoutStatus === 'failed' ? 'processing' : payoutStatus,
            updated_at: new Date().toISOString(),
          }).eq('id', withdrawal.id)
          if (payoutStateError) {
            throw new Error(`Provider payout ${providerPayoutId} was accepted, but its withdrawal state could not be saved; reconciliation required`)
          }

          if (payoutStatus === 'completed' || payoutStatus === 'failed') {
            await finalizeProviderWithdrawal(withdrawal.id, providerPayoutId, payoutStatus, payoutResult.error_description || payoutResult.failure_reason)
          } else {
            const { error: transactionError } = await supabaseAdmin.from('transactions').update({
              status: 'pending',
              description: `Withdrawal via Razorpay Payout (${providerPayoutId})`,
            }).eq('metadata->>withdrawal_id', withdrawal.id)
            if (transactionError) {
              throw new Error(`Provider payout ${providerPayoutId} was accepted, but its transaction state could not be saved; reconciliation required`)
            }
          }

        } else if (wdMethod === 'paypal') {
          // ── PayPal Payouts API: POST /v1/payments/payouts ──
          const senderBatchId = `wd_${withdrawal.id}_${Date.now()}`
          const payoutResult = await paypalFetch('/v1/payments/payouts', {
            method: 'POST',
            body: JSON.stringify({
              sender_batch_header: {
                sender_batch_id: senderBatchId,
                email_subject: 'You have received a payment from Growlanzo!',
                email_message: `You have received ${formatCurrency(netAmount)} from Growlanzo. It may take up to 1-3 business days to appear.`,
              },
              items: [{
                recipient_type: 'EMAIL',
                amount: { value: netAmount.toFixed(2), currency: 'USD' },
                receiver: paypal_email,
                note: 'Payment from Growlanzo',
                sender_item_id: `wd_${withdrawal.id.slice(0, 8)}`,
              }],
            }),
          })

          const batchHeader = payoutResult.batch_header
          providerPayoutId = batchHeader?.payout_batch_id
          const ppStatus = batchHeader?.batch_status || 'PENDING'
          if (ppStatus === 'SUCCESS') payoutStatus = 'completed'
          else if (['DENIED', 'CANCELED'].includes(ppStatus)) payoutStatus = 'failed'
          else payoutStatus = 'processing'

          const { error: payoutStateError } = await supabaseAdmin.from('withdrawals').update({
            paypal_payout_id: providerPayoutId,
            status: payoutStatus === 'completed' || payoutStatus === 'failed' ? 'processing' : payoutStatus,
            updated_at: new Date().toISOString(),
          }).eq('id', withdrawal.id)
          if (payoutStateError) {
            throw new Error(`Provider payout ${providerPayoutId} was accepted, but its withdrawal state could not be saved; reconciliation required`)
          }

          if (payoutStatus === 'completed' || payoutStatus === 'failed') {
            await finalizeProviderWithdrawal(withdrawal.id, providerPayoutId, payoutStatus, batchHeader?.errors?.[0]?.message)
          } else {
            const { error: transactionError } = await supabaseAdmin.from('transactions').update({
              status: 'pending',
              description: `Withdrawal via PayPal (${providerPayoutId})`,
            }).eq('metadata->>withdrawal_id', withdrawal.id)
            if (transactionError) {
              throw new Error(`Provider payout ${providerPayoutId} was accepted, but its transaction state could not be saved; reconciliation required`)
            }
          }
        }

      } catch (payoutError: any) {
        const errorMsg = payoutError?.message || 'Payout API call failed'

        // Once the provider returns a payout ID, money may already have moved.
        // Do not restore the wallet balance or describe this as an ordinary
        // provider failure when only local reconciliation failed.
        if (providerPayoutId && errorMsg.includes('reconciliation required')) {
          await supabaseAdmin.from('withdrawals').update({
            status: 'processing',
            failure_reason: errorMsg,
            updated_at: new Date().toISOString(),
          }).eq('id', withdrawal.id)
          await supabaseAdmin.from('transactions').update({
            status: 'pending',
            description: `Provider payout ${providerPayoutId} accepted; ledger reconciliation required`,
          }).eq('metadata->>withdrawal_id', withdrawal.id)
          console.error(`[RECONCILIATION REQUIRED] Withdrawal ${withdrawal.id}, provider payout ${providerPayoutId}`)
          return new Response(JSON.stringify({
            success: false,
            payout_completed: payoutStatus === 'completed',
            reconciliation_required: true,
            withdrawal_id: withdrawal.id,
            payout_id: providerPayoutId,
            message: 'The payout provider accepted this transfer, but the wallet ledger could not be finalized. Funds remain held while the transfer is reconciled.',
          }), { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
        }

        // ── CONFIG / NOT-READY errors → QUEUE, don't hard-fail ──────────────
        // RazorpayX may not be enabled on the account yet ("The requested URL
        // was not found on the server" = /v1/payouts 404) or credentials may be
        // missing. Instead of failing the whole withdrawal, keep it 'pending'
        // with funds held — the financial cron (process_stale_withdrawals)
        // retries it automatically once the payout service is configured. The
        // freelancer sees a clean "Withdrawal queued" instead of a raw error.
        const configLike = /url was not found|not found on the server|invalid account|account.*not.*exist|payouts.*not.*enabled|not configured|invalid.*credential|missing.*credential|unauthorized|payment processing is not enabled/i.test(errorMsg)
        if (configLike) {
          await supabaseAdmin.from('withdrawals').update({
            status: 'pending',
            failure_reason: `Queued — payout service not configured yet. ${errorMsg}`,
            updated_at: new Date().toISOString(),
          }).eq('id', withdrawal.id)

          // Keep the transaction pending (funds stay held in the wallet).
          await supabaseAdmin.from('transactions').update({
            status: 'pending',
            description: `Withdrawal queued (${wdMethod}) — awaiting payout service`,
          }).eq('metadata->>withdrawal_id', withdrawal.id)

          return new Response(JSON.stringify({
            success: true,
            payout_completed: false,
            queued: true,
            withdrawal: {
              id: withdrawal.id,
              amount: withdrawal.amount,
              fee: withdrawal.fee,
              net_amount: withdrawal.net_amount,
              status: 'pending',
              method: withdrawal.method,
            },
            message: 'Withdrawal queued. Your funds are safely held — the payout will be processed as soon as the payout service is configured.',
          }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
        }

        // ── REAL FAILURE → Rollback ──
        await rollbackWithdrawal(withdrawal.id, user.id, amount, errorMsg)
        
        // Send failure notification email (fire-and-forget)
        sendNotificationEmail(
          user.email || '',
          user.user_metadata?.name || user.email?.split('@')[0] || 'User',
          `Withdrawal of ${formatCurrency(amount)} Failed — Funds Returned 💔`,
          buildWithdrawalEmail(
            user.user_metadata?.name || user.email?.split('@')[0] || 'User',
            amount, amount, wdMethod, 'failed', errorMsg
          ),
        );

        return new Response(JSON.stringify({ success: false, error: errorMsg, withdrawal_id: withdrawal.id, rollback: true }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      if (payoutStatus === 'completed') {
        sendNotificationEmail(
          user.email || '',
          user.user_metadata?.name || user.email?.split('@')[0] || 'User',
          `Withdrawal of ${formatCurrency(amount)} Processed Successfully ✅`,
          buildWithdrawalEmail(
            user.user_metadata?.name || user.email?.split('@')[0] || 'User',
            amount, netAmount, wdMethod, 'completed'
          ),
        );
      } else if (payoutStatus === 'failed') {
        sendNotificationEmail(
          user.email || '',
          user.user_metadata?.name || user.email?.split('@')[0] || 'User',
          `Withdrawal of ${formatCurrency(amount)} Failed — Funds Returned 💔`,
          buildWithdrawalEmail(
            user.user_metadata?.name || user.email?.split('@')[0] || 'User',
            amount, amount, wdMethod, 'failed', 'The payout provider declined the transfer.'
          ),
        );
        return new Response(JSON.stringify({
          success: false,
          payout_completed: false,
          withdrawal: { id: withdrawal.id, amount: withdrawal.amount, fee: withdrawal.fee, net_amount: withdrawal.net_amount, status: 'failed', method: withdrawal.method, payout_id: providerPayoutId },
          message: 'The payout provider declined this transfer. The held funds were returned to your wallet.',
        }), { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
      }

      return new Response(JSON.stringify({
        success: true, payout_completed: payoutStatus === 'completed',
        withdrawal: { id: withdrawal.id, amount: withdrawal.amount, fee: withdrawal.fee, net_amount: withdrawal.net_amount, status: payoutStatus, method: withdrawal.method, payout_id: providerPayoutId },
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (method === 'GET') {
      // Get withdrawal history
      const { data: withdrawals, error } = await supabaseClient
        .from('withdrawals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (error) {
        throw error
      }

      return new Response(
        JSON.stringify({ withdrawals }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Withdrawal error:', error)
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})