// Razorpay Payout Webhook Edge Function
// Receives payout status updates from RazorpayX via webhooks
// Updates withdrawal records and transactions accordingly

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { getCorsHeaders } from '../_shared/cors.ts'


Deno.serve(async (req) => {
  const origin = req.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Verify webhook secret — FAIL CLOSED: if not configured, reject the
    // webhook rather than processing unverified payout events.
    // A RazorpayX payout webhook is configured with its own secret; accept the
    // payout-specific name first and fall back to the shared one so existing
    // deployments keep working. Never default to an empty string.
    const webhookSecret =
      Deno.env.get('RAZORPAY_PAYOUT_WEBHOOK_SECRET') || Deno.env.get('RAZORPAY_WEBHOOK_SECRET')
    if (!webhookSecret) {
      console.error('Payout webhook secret is not configured — rejecting webhook (fail closed)')
      return new Response(JSON.stringify({ error: 'Webhook not configured' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }
    const signature = (req.headers.get('x-razorpay-signature') || '').trim().toLowerCase()
    const bodyText = await req.text()

    // HMAC-SHA256 over the EXACT raw request bytes. The previous code imported
    // the key with the verify-only usage and then called crypto.subtle.sign(),
    // which throws InvalidAccessError — so no delivery could ever verify.
    const encoder = new TextEncoder()
    const key = await crypto.subtle.importKey(
      'raw', encoder.encode(webhookSecret),
      { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
    )
    const signatureBytes = await crypto.subtle.sign('HMAC', key, encoder.encode(bodyText))
    const expectedSig = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('')

    // Length check first (a mismatched length is a forgery, not a near miss),
    // then a constant-time comparison of equal-length hex strings.
    if (signature.length === 0 || signature.length !== expectedSig.length) {
      console.error('Invalid webhook signature (length mismatch)')
      return new Response(JSON.stringify({ error: 'Invalid signature' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }
    let diff = 0
    for (let i = 0; i < expectedSig.length; i++) {
      diff |= signature.charCodeAt(i) ^ expectedSig.charCodeAt(i)
    }
    if (diff !== 0) {
      console.error('Invalid webhook signature')
      return new Response(JSON.stringify({ error: 'Invalid signature' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const event = JSON.parse(bodyText)
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false, autoRefreshToken: false } }
    )

    const eventType = event.event
    const payload = event.payload
    const payout = payload?.payout?.entity

    if (!payout) {
      console.log('No payout entity in webhook payload')
      return new Response(JSON.stringify({ received: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const razorpayPayoutId = payout.id
    const payoutStatus = payout.status
    const failureReason = payout.failure_reason || null

    console.log(`Processing payout webhook: ${eventType} for payout ${razorpayPayoutId}`)

    // Map RazorpayX payout status to our status
    let newStatus: string
    if (payoutStatus === 'processed' || payoutStatus === 'completed') {
      newStatus = 'completed'
    } else if (payoutStatus === 'failed' || payoutStatus === 'cancelled' || payoutStatus === 'reversed') {
      newStatus = 'failed'
    } else if (payoutStatus === 'queued' || payoutStatus === 'processing') {
      newStatus = 'processing'
    } else {
      console.log(`Unhandled payout status: ${payoutStatus}`)
      newStatus = 'processing'
    }

    // Find the withdrawal by razorpay_payout_id
    const { data: withdrawal, error: withdrawalLookupError } = await supabaseClient
      .from('withdrawals')
      .select('id, user_id, amount, status')
      .eq('razorpay_payout_id', razorpayPayoutId)
      .maybeSingle()

    if (withdrawalLookupError) {
      console.error('Unable to resolve payout webhook to a withdrawal')
      return new Response(JSON.stringify({ error: 'Unable to resolve payout' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    if (!withdrawal) {
      console.log(`No withdrawal found for payout ID: ${razorpayPayoutId}`)
      return new Response(JSON.stringify({ received: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    // ── IDEMPOTENCY: skip if already in terminal state ────────────────────
    // Prevents double-release of wallet funds on RazorpayX webhook replays
    if (withdrawal.status === 'completed' || withdrawal.status === 'failed') {
      console.log(`Withdrawal ${withdrawal.id} already in terminal status: ${withdrawal.status} — skipping`)
      return new Response(JSON.stringify({ received: true, skipped: true, reason: 'already_terminal' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    if (newStatus === 'failed' || newStatus === 'completed') {
      // Terminal payout statuses must go through the internal, service-role-only
      // RPC so wallet, withdrawal, and transaction rows change atomically.
      const { data: finalization, error: finalizationError } = newStatus === 'completed'
        ? await supabaseClient.rpc('process_withdrawal_complete', { p_withdrawal_id: withdrawal.id })
        : await supabaseClient.rpc('process_withdrawal_failure', {
          p_withdrawal_id: withdrawal.id,
          p_failure_reason: failureReason || 'Payout failed at RazorpayX',
        })

      if (finalizationError || !finalization?.success) {
        console.error(`Payout ${razorpayPayoutId} reached ${newStatus}, but ledger finalization failed; reconciliation required`)
        return new Response(JSON.stringify({ error: 'Payout recorded for reconciliation' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }
    } else {
      const { error: updateError } = await supabaseClient
        .from('withdrawals')
        .update({ status: newStatus, failure_reason: failureReason, updated_at: new Date().toISOString() })
        .eq('id', withdrawal.id)
        .in('status', ['pending', 'processing'])

      if (updateError) {
        console.error(`Payout ${razorpayPayoutId} nonterminal status could not be saved`)
        return new Response(JSON.stringify({ error: 'Payout status update failed' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }
    }

    return new Response(JSON.stringify({ received: true, withdrawal_id: withdrawal.id, new_status: newStatus }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })

  } catch (error) {
    console.error('Razorpay payout webhook error:', error)
    return new Response(JSON.stringify({ error: 'Webhook processing failed' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
