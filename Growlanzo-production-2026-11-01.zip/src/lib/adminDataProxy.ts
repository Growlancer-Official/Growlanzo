/**
 * Admin Data Proxy — Helper for admin pages to fetch data via edge function
 * 
 * All admin pages use this instead of direct supabase queries because
 * RLS blocks unauthenticated requests. The edge function uses service_role
 * key internally (bypasses RLS).
 * 
 * Auth uses the standard Supabase session — supabase.functions.invoke()
 * automatically sends the Authorization: Bearer <token> header from the
 * current session, so no manual token handling is needed.
 */
import { supabase } from './supabase';

const FN = 'admin-data';

type QueryOptions = {
  table: string;
  select?: string;
  order?: string;
  orderDir?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
  filters?: Record<string, string>;
  isNull?: Record<string, boolean>;
  gte?: Record<string, string>;
  lte?: Record<string, string>;
  in?: Record<string, string[]>;
  count?: 'exact' | 'planned';
  head?: boolean;
};

/**
 * Failures worth one retry: a cold start / gateway blip on a read, not an
 * authorisation decision. A 4xx is the function's answer and is never retried.
 */
function isTransientFunctionError(error: unknown): boolean {
  const status = (error as { context?: { status?: number } })?.context?.status;
  if (typeof status === 'number') return status >= 500 || status === 408 || status === 429;
  // No status at all: the request never completed (network / FunctionsFetchError).
  return /failed to send|failed to fetch|network|timeout|timed out/i.test(
    String((error as Error)?.message ?? error ?? ''),
  );
}

/**
 * Read-only invoke with a single retry. Writes are deliberately NOT retried:
 * replaying a mutation after an ambiguous failure could double-apply it.
 */
async function invokeRead<T>(body: Record<string, unknown>): Promise<T | null> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const { data, error } = await supabase.functions.invoke(FN, { method: 'POST', body });
    if (!error) return data as T;
    if (attempt === 1 || !isTransientFunctionError(error)) throw error;
    await new Promise((resolve) => setTimeout(resolve, 600));
  }
  return null;
}

/**
 * Execute a generic query via the admin-data edge function (POST).
 * Returns { data, total }.
 */
export async function adminQuery<T = any>(options: QueryOptions): Promise<{ data: T[]; total?: number }> {
  const result = await invokeRead<{ data?: T[]; total?: number }>({
    action: 'query',
    table: options.table,
    select: options.select || '*',
    order: options.order,
    orderDir: options.orderDir,
    limit: options.limit ?? 100,
    offset: options.offset ?? 0,
    count: options.count,
    head: options.head,
    filters: options.filters,
    isNull: options.isNull,
    gte: options.gte,
    lte: options.lte,
    in: options.in,
  });

  return { data: result?.data || [], total: result?.total };
}

/**
 * Get counts for multiple tables at once.
 */
export async function adminCounts(tables: string[]): Promise<Record<string, number>> {
  const result = await invokeRead<{ counts?: Record<string, number> }>({ action: 'counts', tables });
  return result?.counts || {};
}

/**
 * Update a record via the admin-data edge function.
 */
export async function adminUpdate(table: string, id: string, data: Record<string, any>, idField = 'id'): Promise<any> {
  const { data: result, error } = await supabase.functions.invoke(FN, {
    method: 'PATCH',
    body: { table, id, id_field: idField, data },
  });

  if (error) throw error;
  return (result as any)?.data;
}

/**
 * Delete a record via the admin-data edge function.
 */
export async function adminDelete(table: string, id: string, idField = 'id'): Promise<any> {
  const { data: result, error } = await supabase.functions.invoke(FN, {
    method: 'DELETE',
    body: { table, id, id_field: idField },
  });

  if (error) throw error;
  return (result as any)?.data;
}

/**
 * Insert a record via the admin-data edge function.
 */
export async function adminInsert(table: string, data: Record<string, any>): Promise<any> {
  const { data: result, error } = await supabase.functions.invoke(FN, {
    method: 'POST',
    body: { action: 'insert', table, data },
  });

  if (error) throw error;
  return (result as any)?.data;
}

/**
 * Run the orphan-data purge (wipes ALL data of profiles whose auth.users row
 * is gone). Returns { success, result } where result is the purge report.
 */
export async function adminPurgeOrphans(): Promise<{ success: boolean; result?: any; error?: string }> {
  const { data: result, error } = await supabase.functions.invoke(FN, {
    method: 'POST',
    body: { action: 'purge_orphans' },
  });

  if (error) throw error;
  return result as { success: boolean; result?: any; error?: string };
}
