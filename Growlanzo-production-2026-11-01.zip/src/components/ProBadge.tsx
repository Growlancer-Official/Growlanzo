import { Crown } from 'lucide-react';

interface ProBadgeProps {
  size?: 'xs' | 'sm' | 'md';
  className?: string;
  /** Tooltip side: 'top' (default) in-content, 'bottom' inside sticky headers. */
  placement?: 'top' | 'bottom';
}

/**
 * Professional PRO badge for Growlanzo Pro members.
 * Always shows a premium "PRO" text pill (not a blue check icon) so it reads
 * clearly next to the green KYC verified badge — no more two identical check
 * circles. Hovering reveals a polished tooltip ("Pro Freelancer").
 */
export function ProBadge({ size = 'sm', className = '', placement = 'top' }: ProBadgeProps) {
  const sizes = {
    xs: { pill: 'text-[10px] px-1.5 py-px gap-0.5', icon: 'w-2.5 h-2.5', tooltip: 'text-xs px-2 py-1' },
    sm: { pill: 'text-[10px] px-2 py-0.5 gap-1', icon: 'w-3.5 h-3.5', tooltip: 'text-xs px-2.5 py-1' },
    md: { pill: 'text-xs px-2.5 py-1 gap-1', icon: 'w-4 h-4', tooltip: 'text-xs px-3 py-1.5' },
  }[size];

  const below = placement === 'bottom';

  const base = `relative group inline-flex items-center rounded-md bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-800 text-white font-extrabold uppercase tracking-wider shadow-sm ring-1 ring-emerald-900/30 ${sizes.pill} ${className}`;

  return (
    <span
      className={base}
      role="img"
      aria-label="Growlanzo Pro Member"
    >
      <Crown className={`${sizes.icon} fill-amber-300/90 text-amber-300`} strokeWidth={2} />
      <span className="leading-none">PRO</span>

      {/* Polished hover tooltip — same anchoring rule as VerifiedBadge:
          right-anchored ONLY in 'bottom' (header) placement, where the badge sits
          near the viewport's right edge; centered in default 'top' placement so
          in-content badges near the left edge never lose the tooltip off-screen. */}
      <span
        role="tooltip"
        className={`pointer-events-none absolute z-50 whitespace-nowrap rounded-lg bg-slate-900 text-white font-semibold normal-case tracking-normal shadow-xl opacity-0 transition-opacity duration-200 group-hover:opacity-100 ${below ? 'right-0 top-full mt-1.5 text-right' : 'left-1/2 -translate-x-1/2 -top-1 -translate-y-full text-center'} ${sizes.tooltip}`}
      >
        Pro Freelancer
        <span className={`absolute border-4 border-transparent ${below ? 'right-2 bottom-full border-b-slate-900' : 'left-1/2 -translate-x-1/2 top-full border-t-slate-900'}`} />
      </span>
    </span>
  );
}

export default ProBadge;
