import { describe, it, expect } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * Regression tests for the guardrails INSIDE the workflows.
 *
 * The failure these exist to prevent is a status-reporting one, not a code one:
 * the authenticated element audit and the privilege pentest were both gated on
 * secrets that were simply absent, so they *skipped* — and the job reported
 * SUCCESS. A green check on top of a guardrail that never ran is worse than a
 * red one, because it is trusted.
 *
 * So these tests read the workflow files and assert:
 *   - a missing secret fails the run (no skip path that exits 0 for these two),
 *   - the only tolerated skip is the one GitHub makes unavoidable (fork PRs),
 *     and it is announced loudly rather than passing quietly,
 *   - every credential the guarded steps consume is actually asserted,
 *   - the deploy's guard runs BEFORE anything is deployed,
 *   - the authenticated audit cannot run partially/logged-out and still pass.
 *
 * If you change a workflow and these fail, do not delete the assertion: either
 * make the workflow fail closed again, or replace the guard with a stronger one.
 */

const workflowsDir = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  '../../.github/workflows'
);

const readWorkflow = (file: string) =>
  fs.readFileSync(path.join(workflowsDir, file), 'utf8').replace(/\r\n/g, '\n');

const CI = readWorkflow('ci.yml');
const DEPLOY = readWorkflow('backend-deploy.yml');
const readScript = (file: string) =>
  fs
    .readFileSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), `../../scripts/e2e/${file}`), 'utf8')
    .replace(/\r\n/g, '\n');

const LOGIN = readScript('login.mjs');
const CREATE_ACCOUNTS = readScript('create-test-accounts.mjs');

/**
 * Drop line comments (YAML `#` and shell `#` alike) before asserting that a
 * construct is ABSENT. Otherwise documentation *about* the thing it forbids —
 * the comment explaining why the old `can_seed_e2e` gate was removed — would be
 * what fails the test. What must not exist is a live gate, not prose about one.
 */
const stripComments = (source: string) =>
  source
    .split('\n')
    .filter((line) => !/^\s*#/.test(line))
    .join('\n');

/** The text of one step: from its `- name:` line up to the next step. */
function stepBlock(source: string, name: string): string {
  const lines = source.split('\n');
  const start = lines.findIndex((l) => l.includes(`- name: ${name}`));
  if (start === -1) throw new Error(`workflow step not found: "${name}"`);
  const rest = lines.slice(start + 1);
  const end = rest.findIndex((l) => /^\s{6}- /.test(l));
  const block = end === -1 ? rest : rest.slice(0, end);
  return [lines[start], ...block].join('\n');
}

/**
 * The contiguous YAML comment block written directly above a step.
 *
 * Whole block, not just the nearest line: a comment explaining a flag is
 * normally spread over several lines, so reading only `lastIndexOf` would
 * assert against the tail of the sentence.
 */
function leadingCommentBlock(source: string, stepName: string): string {
  const lines = source.split('\n');
  const at = lines.findIndex((l) => l.includes(`- name: ${stepName}`));
  if (at === -1) throw new Error(`workflow step not found: "${stepName}"`);
  const collected: string[] = [];
  for (let i = at - 1; i >= 0 && /^\s*#/.test(lines[i]); i--) {
    collected.unshift(lines[i]);
  }
  return collected.join('\n');
}

/** Keys of a job's top-level `env:` block (a job's step env is nested deeper). */
function jobEnvKeys(source: string, jobName: string): string[] {
  const lines = source.split('\n');
  const jobStart = lines.findIndex((l) => l === `  ${jobName}:`);
  if (jobStart === -1) throw new Error(`job not found: "${jobName}"`);
  const envStart = lines.findIndex((l, i) => i > jobStart && l === '    env:');
  if (envStart === -1) throw new Error(`job "${jobName}" has no top-level env block`);
  const keys: string[] = [];
  for (const line of lines.slice(envStart + 1)) {
    const m = /^ {6}([A-Z][A-Z0-9_]*):/.exec(line);
    if (!m) break;
    keys.push(m[1]);
  }
  return keys;
}

describe('ci.yml — the authenticated audit cannot silently not-run', () => {
  const guard = stepBlock(CI, 'Guard — authenticated-audit secrets present (fail-closed)');

  it('fails the job (not skips it) when a required secret is missing', () => {
    expect(guard).toContain('::error::');
    expect(guard).toMatch(/exit 1/);
    // The old silent gate is gone for good (executable lines only — the comment
    // explaining its removal is allowed to name it).
    expect(stripComments(CI)).not.toContain('can_seed_e2e');
  });

  it('asserts every credential its job env consumes', () => {
    const required = /REQUIRED="([^"]+)"/.exec(guard)?.[1]?.split(/\s+/) ?? [];
    expect(required.length).toBeGreaterThan(0);
    const consumed = jobEnvKeys(CI, 'element-audit');
    expect(consumed).toContain('SUPABASE_SERVICE_ROLE_KEY');
    // A new credential added to the job env without adding it here would let the
    // pass run half-configured, so hold the two lists together.
    for (const key of consumed) {
      expect(required, `job env ${key} is not asserted by the guard`).toContain(key);
    }
  });

  it('tolerates a skip only for a fork PR, and says so out loud', () => {
    const skipBranch = guard.slice(guard.indexOf('exit 0') - 600, guard.indexOf('exit 0'));
    expect(skipBranch).toContain('pull_request');
    expect(skipBranch).toContain('fork');
    // Announced, never silent — and it still reports that the pass did not run.
    expect(skipBranch).toContain('::warning::');
    expect(guard).toContain('run_authenticated=false');
    // The skip is the ONLY exit 0 in the guard: every other path must fail.
    expect(guard.match(/exit 0/g)?.length).toBe(1);
  });

  it('publishes exactly one gate the downstream steps depend on', () => {
    expect(guard).toContain('run_authenticated=true');
    for (const step of [
      'Seed E2E test accounts (live only for this run)',
      'Authenticated audit + logout security (freelancer/client/admin)',
      'Remove E2E test accounts from production',
    ]) {
      const block = stepBlock(CI, step);
      const condition = /^\s+if: (.*)$/m.exec(block)?.[1] ?? '';
      expect(condition, `"${step}" is not gated on the guard`).toContain(
        'steps.e2e_guard.outputs.run_authenticated'
      );
    }
  });

  it('cannot run the authenticated audits partially or logged-out', () => {
    const audit = stepBlock(CI, 'Authenticated audit + logout security (freelancer/client/admin)');
    // Strict login: every role must end up with a storage state.
    expect(audit).toContain('--require-all');
    // No `if [ -f .e2e/<role>.json ]` wrapping: that pattern dropped a role that
    // failed to log in and still left the job green.
    expect(audit).not.toMatch(/if \[ -f \.e2e\//);
    // All three role audits and all three logout flows are unconditional.
    for (const group of ['dashboard', 'client', 'admin']) {
      expect(audit).toContain(`--group=${group}`);
    }
    expect(audit.match(/logout-flow\.mjs/g)?.length).toBe(1); // inside the for-loop
    expect(audit).toContain('for role in freelancer client admin');
  });

  it('never marks a guard step as allowed to fail', () => {
    expect(stripComments(CI)).not.toContain('continue-on-error');
    expect(stripComments(DEPLOY)).not.toContain('continue-on-error');
  });

  it('implements the strict login contract it relies on', () => {
    expect(LOGIN).toContain("args['require-all']");
    // A missing credential must throw in strict mode rather than return null.
    expect(LOGIN).toMatch(/REQUIRE_ALL[\s\S]{0,400}throw new Error/);
  });
});

describe('the E2E seed cannot write to an account it does not own', () => {
  /**
   * On 2026-09-25 this script reset a REAL user's password and overwrote their
   * profile name + email. Cause: `GET /auth/v1/admin/users?email=…` — GoTrue
   * silently ignores that parameter and returns the first page of users, so
   * `users[0]` was whoever happened to come first, and the seed took its
   * "account already exists" branch against them. A lookup that cannot verify
   * what it found is not a lookup.
   */
  it('matches the email locally instead of asking the API to filter', () => {
    // The exact broken call — prose in comments is allowed to mention it.
    expect(CREATE_ACCOUNTS).not.toContain('/auth/v1/admin/users?email=');
    expect(CREATE_ACCOUNTS).not.toContain('body.users?.[0]');
    expect(CREATE_ACCOUNTS).toContain('per_page=200');
    expect(CREATE_ACCOUNTS).toMatch(/\.find\(\(u\) => \(u\.email \|\| ''\)\.trim\(\)\.toLowerCase\(\) === wanted\)/);
  });

  it('proves the id it is about to write to carries the account email', () => {
    expect(CREATE_ACCOUNTS).toMatch(/adminGetById\(id\)/);
    expect(CREATE_ACCOUNTS).toContain('WRONG_USER');
  });

  it('fails the step instead of printing OK for an unusable account', () => {
    for (const code of ['CREATE_FAILED', 'UPDATE_FAILED', 'PROFILE_FAILED', 'STATE_FAILED', 'ADMIN_ROLE_FAILED']) {
      expect(CREATE_ACCOUNTS).toContain(code);
    }
    expect(CREATE_ACCOUNTS).toMatch(/if \(failures\.length\)[\s\S]{0,300}process\.exit\(1\)/);
    // Never push secrets derived from a half-built account set.
    expect(CREATE_ACCOUNTS.indexOf('failures.length')).toBeLessThan(
      CREATE_ACCOUNTS.indexOf("'--push-secrets'")
    );
  });

  it('leaves the accounts fully onboarded — the state the audits assume', () => {
    // onboardingCompleted === false routes every login to /onboarding, so
    // logout-flow's "login reaches the dashboard" step could never pass.
    expect(CREATE_ACCOUNTS).toContain('onboarding_completed: true');
    expect(CREATE_ACCOUNTS).toMatch(/setOnboardedState\(id, 'India'\)/);
    expect(CREATE_ACCOUNTS).toMatch(/onboardingCompleted !== true \|\| state\.country !== 'India'/);
  });

  it('reads the admin grant back instead of trusting an HTTP 200', () => {
    // grant_admin_role refuses with 200 + {success:false}; that is how the admin
    // sweep was once seeded with an account that could not see admin pages.
    expect(CREATE_ACCOUNTS).toContain('success === true');
    expect(CREATE_ACCOUNTS).toMatch(/profiles_private\?id=eq\.\$\{id\}&select=is_admin/);
    expect(CREATE_ACCOUNTS).toContain('flagged !== true');
  });

  it('consumes the anonymous key it exchanges credentials with', () => {
    // The token grant is called with the public anon key; a missing key would
    // make every login attempt fail with a confusing 401 instead of a named
    // misconfiguration, so the job env carries it and the guard asserts it.
    const ciGuard = stepBlock(CI, 'Guard — authenticated-audit secrets present (fail-closed)');
    const required = /REQUIRED="([^"]+)"/.exec(ciGuard)?.[1]?.split(/\s+/) ?? [];
    expect(required).toContain('VITE_SUPABASE_ANON_KEY');
    const consumed = jobEnvKeys(CI, 'element-audit');
    expect(consumed).toContain('VITE_SUPABASE_ANON_KEY');
  });

  it('requires the admin CONSOLE, not just a stored session', () => {
    // A signed-in non-admin gets AdminLoginPage at /admin; auditing that page
    // would report the logged-out surface as green.
    expect(LOGIN).toContain('input[aria-label="Admin password"]');
    expect(LOGIN).toContain("role === 'admin' ? sawRoute : sawSession || sawRoute");
  });

  it('reports the auth endpoint\'s real reason, not a getter\'s source', () => {
    // login.mjs performs the credential exchange directly against GoTrue
    // (`POST /auth/v1/token?grant_type=password`) and seeds the session — the
    // product's sign-in is GitHub/LinkedIn only, so there is no form to fill.
    expect(LOGIN).toContain('grant_type=password');
    expect(LOGIN).toContain('addInitScript');
    // It reads the error body, so invalid_credentials is nameable.
    expect(LOGIN).toMatch(/error_code[\s\S]{0,200}error_description/);
    // The session it writes must be the real thing, verified in storage.
    expect(LOGIN).toContain('storageKeyFor');
  });
});

const ELEMENT_AUDIT = readScript('element-audit.mjs');
const LOGOUT_FLOW = readScript('logout-flow.mjs');

describe('the authenticated sweeps cannot pass on a logged-out surface', () => {
  /**
   * Measured 2026-09-27 against three DEAD storage states — each one rendered a
   * logged-out page that the sweep would have reported as clean:
   *   /dashboard → stayed on the path, empty shell, no logout control
   *   /client    → redirected to / and audited the marketing homepage 72 times
   *   /admin     → rendered its own "Restricted Access" login gate 51 times
   * login.mjs verifies the session AT LOGIN TIME; nothing re-verified it during
   * the sweep, so a session that died mid-run produced a false green. The audit
   * now carries its own proof that each protected load WAS authenticated.
   */
  it('records the auth chrome each authenticated load actually rendered', () => {
    expect(ELEMENT_AUDIT).toContain('authChrome');
    expect(ELEMENT_AUDIT).toMatch(/logoutControl:/);
    expect(ELEMENT_AUDIT).toMatch(/loggedOutGate:/);
  });

  it('detects the logout control by text OR attribute — either alone fails a healthy surface', () => {
    /**
     * Measured 2026-09-28 with live sessions, 3 roles × 3 viewports × 3 routes:
     *   text-only      → 18/27 matches (9 false positives, every one of them admin)
     *   attribute-only →  9/27 matches
     *   union          → 27/27 matches
     * The admin header's logout is an icon-only <button title="Logout from Admin">,
     * so its label is an ATTRIBUTE and appears in neither innerText nor
     * textContent; the freelancer/client sidebars carry a literal <span>Logout</span>
     * and no such attribute. A revert to the text-only regex would make the admin
     * sweep permanently unrunnable — the exact gate this guard exists to close.
     */
    expect(ELEMENT_AUDIT).toMatch(/title\*="logout" i/);
    expect(ELEMENT_AUDIT).toMatch(/aria-label\*="logout" i/);
    expect(ELEMENT_AUDIT).toMatch(/logoutControl:\s*logoutText \|\| Boolean\(logoutAttrEl\)/);
    // The old text-only form must not come back.
    expect(ELEMENT_AUDIT).not.toMatch(/logoutControl:\s*\//);
    // The per-load signal is artifact evidence, not an internal detail.
    expect(ELEMENT_AUDIT).toMatch(/logoutSignal:/);
  });

  it('fails a dead session from GoTrue traffic, not from DOM shape (which flaps)', () => {
    /**
     * Measured 2026-09-28 against a revoked admin storage state: chrome shape is
     * not a trustworthy discriminator. /admin/users rendered its "Restricted
     * Access" gate at ~1.0 s and then FLIPPED BACK to the stale authenticated
     * layout — logout button present — at ~1.4 s, while live loads only painted
     * their logout control at ~2.2 s. 6 of 12 revoked loads still matched the
     * logout control, so a shape-only guard can pass a dead session.
     * GoTrue traffic is an event, not a shape: live → token/refresh 200 + user
     * 200; revoked → token/refresh 400 and no user call at all. A load whose
     * GoTrue responses ALL failed never proved it held a session.
     */
    // The event source, and the fail-closed verdict derived from it.
    expect(ELEMENT_AUDIT).toContain('AUTH_ENDPOINT_RE = /\\/auth\\/v1\\/(token|user)$/');
    expect(ELEMENT_AUDIT).toContain('dead: authEvents.length > 0 && authOk.length === 0');
    // It must be able to reject a load whose DOM *looked* authenticated.
    expect(ELEMENT_AUDIT).toContain('stale authenticated chrome');
    expect(ELEMENT_AUDIT).toMatch(/else if \(authSession\.dead\)/);
    // Evidence flows into the artifact and the CI annotation, so a green run
    // still shows WHY each load was accepted (or was rejected).
    expect(ELEMENT_AUDIT).toMatch(/authSession: STORAGE/);
    expect(ELEMENT_AUDIT).toContain('GoTrue-rejected loads=');
  });

  it('counts a logged-out surface as an issue and fails the run regardless of --strict', () => {
    expect(ELEMENT_AUDIT).toMatch(/function issueCount[\s\S]{0,200}authViolations/);
    expect(ELEMENT_AUDIT).toContain('left the authenticated surface');
    expect(ELEMENT_AUDIT).toMatch(/if \(summary\.authViolations\.length\)[\s\S]{0,1200}process\.exit\(1\)/);
    expect(ELEMENT_AUDIT).toMatch(/::error::auth integrity/);
  });

  it('scopes the check to the storage state\'s own surface, not every redirect', () => {
    // /client/inbox → /client/notifications is legitimate app behaviour while
    // signed in; leaving /client altogether is the dead-session signature.
    expect(ELEMENT_AUDIT).toMatch(/freelancer: \['\/dashboard'\], client: \['\/client'\], admin: \['\/admin'\]/);
    expect(ELEMENT_AUDIT).toContain('startsWith(`${prefixNorm}/`)');
  });

  it('no longer skips the logout pass with exit 0 when its credentials are missing', () => {
    expect(LOGOUT_FLOW).not.toContain('Skipping (exit 0)');
    const credentialCheck = LOGOUT_FLOW.slice(0, LOGOUT_FLOW.indexOf('const results'));
    expect(credentialCheck).toMatch(/if \(!CFG\.email \|\| !CFG\.password\)[\s\S]{0,800}process\.exit\(1\)/);
    expect(credentialCheck).toContain('::error::');
  });
});

describe('backend-deploy.yml — a deploy is never green with an unrun pentest', () => {
  const guard = stepBlock(DEPLOY, 'Guard — pentest secrets present (fail-closed)');
  const pentest = stepBlock(DEPLOY, 'Privilege + money-path pentest (against deployed DB)');

  it('asserts every secret the pentest consumes', () => {
    const consumed = [...pentest.matchAll(/secrets\.([A-Z_]+)/g)].map((m) => m[1]);
    expect(consumed).toContain('SUPABASE_SERVICE_ROLE_KEY');
    expect(consumed).toContain('VITE_SUPABASE_ANON_KEY');
    for (const name of consumed) {
      expect(guard, `pentest uses ${name} but the guard does not assert it`).toContain(name);
    }
  });

  it('has no silent skip left in the pentest step', () => {
    const executable = stripComments(pentest);
    expect(executable).not.toContain('::notice::');
    expect(executable).not.toContain('SKIPPED');
    expect(pentest).toMatch(/exit 1/);
    expect(pentest).toContain('node scripts/e2e/pentest-privileges.mjs');
  });

  it('runs the guard BEFORE anything is deployed', () => {
    const guardAt = DEPLOY.indexOf('Guard — pentest secrets present (fail-closed)');
    for (const step of [
      'Migration drift check (repo vs live DB — fail-closed)',
      'Apply pending migrations (db push — no-op when in sync)',
      'Deploy all edge functions from repo source',
    ]) {
      expect(DEPLOY.indexOf(`- name: ${step}`)).toBeGreaterThan(guardAt);
    }
    expect(guard).toMatch(/exit 1/);
  });

  /**
   * Measured 2026-10-15, run 38719764730 — the shape of a red deploy over a
   * correct drift gate:
   *
   *   mode: pre | files: 292 | remote-applied: 276 | pending: 15
   *   Pre-flight OK — 15 migration(s) pending; db push will apply them.
   *   npx supabase db push --db-url "$SUPABASE_DB_URL"
   *   Found local migration files to be inserted before the last migration on
   *   remote database. Rerun the command with --include-all flag …
   *   ##[error]Process completed with exit code 1.
   *
   * The cause was NOT an out-of-order migration: TWO repo files shared version
   * 20270119000000. `db push` matches a repo file to a live row by version, so
   * only the first of the two could ever match; the second sorted as unapplied
   * forever, and pushing it tried to insert a version the remote already owned.
   * `--include-all` does not fix that — it forces the unmatched file in anyway,
   * deleting the one line that reported the duplicate. So the gate stays strict,
   * and the duplicate is caught earlier instead (CI drift helper + repo scan).
   */
  it('keeps db push strict — no flag that would apply a version the remote already owns', () => {
    const push = stepBlock(DEPLOY, 'Apply pending migrations (db push — no-op when in sync)');
    expect(push).toMatch(/supabase db push --db-url "\$SUPABASE_DB_URL"/);
    expect(push).not.toContain('--include-all');
    // Fail-closed ordering is untouched: the drift check still runs first.
    expect(DEPLOY.indexOf('- name: Migration drift check')).toBeLessThan(
      DEPLOY.indexOf('- name: Apply pending migrations')
    );
  });

  it('names the duplicate-version cause next to the push, so the flag is not "restored" as a fix', () => {
    const leadingComment = leadingCommentBlock(DEPLOY, 'Apply pending migrations (db push — no-op when in sync)');
    expect(leadingComment).toContain('--include-all');
    expect(leadingComment).toMatch(/duplicate version|TWO repo files shared version/i);
    // The renumbered file must be named, so "which file was it?" is answerable
    // from the workflow itself, not from this conversation.
    expect(leadingComment).toContain('20270127000000_fix_admin_credentials_rls_and_realtime.sql');
  });

  it('makes the CI drift helper fail closed on a duplicated migration version', () => {
    // A duplicate version is invisible to every other check (both files are
    // valid SQL, and the version IS applied), so this must be a real gate in the
    // helper and must fire in BOTH modes — before the push, so nothing is
    // applied against an ambiguous repo, and after it.
    const helper = DEPLOY.slice(DEPLOY.indexOf('cat > /tmp/driftcheck.mjs'));
    expect(helper).toMatch(/duplicate migration version/);
    expect(helper).toMatch(/const failed = drift \|\| duplicates\.length/);
    expect(helper).toMatch(/const duplicates = /);
  });

  /**
   * The defect itself, asserted against the repo rather than a description of it.
   * Measured 2026-10-15: `20270119000000_fix_admin_credentials_rls_and_realtime.sql`
   * and `20270119000000_harden_internship_auth_policy_and_monitor.sql` both
   * claimed version 20270119000000, and only the latter's name is what the live
   * DB has recorded — i.e. the credential-RLS fix could never have applied.
   */
  it('has exactly one file per migration version', () => {
    const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../supabase/migrations');
    const byVersion = versionsOf(fs.readdirSync(dir).filter((f) => f.endsWith('.sql')));
    const duplicates = [...byVersion.entries()].filter(([, group]) => group.length > 1);

    expect(
      duplicates,
      'One version must name exactly one migration — db push matches by version, so a second ' +
        'file under the same version can never be applied. Renumber it to an unused version:\n' +
        duplicates.map(([v, group]) => `  ${v}: ${group.join(', ')}`).join('\n')
    ).toEqual([]);

    // Guard the guard: a glob that finds nothing, or a predicate that never
    // fires, would make the assertion above pass on any repo at all.
    expect(byVersion.size).toBeGreaterThan(250);
    expect(versionsOf(['20270119000000_a.sql', '20270119000000_b.sql']).size).toBe(1);
    expect(
      [...versionsOf(['20270119000000_a.sql', '20270119000001_b.sql']).values()].every(
        (group) => group.length === 1
      )
    ).toBe(true);
    expect(versionsOf(['not-a-migration.sql']).size).toBe(0);
  });
});

/** Filename → version prefix → the files claiming it. Hoisted, so the test above can use it. */
function versionsOf(files: string[]): Map<string, string[]> {
  const byVersion = new Map<string, string[]>();
  for (const file of files) {
    const version = file.match(/^(\d{6,})/)?.[1];
    if (!version) continue;
    byVersion.set(version, [...(byVersion.get(version) || []), file]);
  }
  return byVersion;
}
