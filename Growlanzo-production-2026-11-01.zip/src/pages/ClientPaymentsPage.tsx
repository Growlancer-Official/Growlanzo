import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase, realtimeChannels } from '../lib/supabase';
import { clientPaymentMethodsService } from '../lib/clientPaymentMethods';
import { razorpayService, type SavedPaymentCard } from '../lib/razorpay';
import type { ClientPaymentMethod } from '../lib/clientPaymentMethods';
import { AlertCircle, ArrowDownLeft, ArrowUpRight, Building2, Calendar, CheckCircle, CreditCard, Download, FileText, Filter, IndianRupee, Loader2, Plus, PlusCircle, Shield, Trash2, Wallet, X } from 'lucide-react';
import { formatCurrency, safeFormatDate, safeNumber } from '../utils/date';
import { currencySymbol } from '../lib/currency';
import { withdrawalService } from '../lib/withdrawal';
import { InfoTip } from '../components/InfoTip';
import { PageSkeleton } from '../components/PageSkeleton';
import { RazorpayCheckout } from '../components/RazorpayCheckout';

interface Transaction {
  id: string;
  user_id: string;
  contract_id?: string;
  escrow_id?: string;
  amount: number;
  type: 'credit' | 'debit';
  source: 'escrow' | 'withdrawal' | 'deposit' | 'refund' | 'platform_fee';
  status: 'pending' | 'completed' | 'failed';
  description?: string;
  created_at: string;
  contract?: {
    id: string;
    project?: {
      title: string;
    };
  };
}

export function ClientPaymentsPage() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'credit' | 'debit'>('all');

  // Payment methods state (manual reference records)
  const [paymentMethods, setPaymentMethods] = useState<ClientPaymentMethod[]>([]);
  const [paymentMethodsLoading, setPaymentMethodsLoading] = useState(false);
  const [paymentMethodsError, setPaymentMethodsError] = useState<string | null>(null);
  const [showAddPaymentMethod, setShowAddPaymentMethod] = useState(false);
  const [addingPaymentMethod, setAddingPaymentMethod] = useState(false);
  const [deletingPaymentMethodId, setDeletingPaymentMethodId] = useState<string | null>(null);
  const [confirmDeletePaymentMethod, setConfirmDeletePaymentMethod] = useState<string | null>(null);
  const [newPaymentMethod, setNewPaymentMethod] = useState({
    type: 'card' as 'card' | 'paypal' | 'bank_transfer',
    cardLastFour: '',
    cardBrand: '',
    cardExpiry: '',
    paypalEmail: '',
    accountHolderName: '',
    accountNumberLastFour: '',
    bankName: '',
    isDefault: false,
  });

  // Saved cards from Razorpay tokenization
  const [savedCards, setSavedCards] = useState<SavedPaymentCard[]>([]);
  const [savedCardsLoading, setSavedCardsLoading] = useState(false);
  const [deletingSavedCardId, setDeletingSavedCardId] = useState<string | null>(null);

  // Auto-generated invoices (on escrow release)
  const [invoices, setInvoices] = useState<any[]>([]);
  const [invoicesLoading, setInvoicesLoading] = useState(false);

  // Wallet — client can add funds (test funds) to fund escrow from wallet
  const [walletBalance, setWalletBalance] = useState(0);
  const [walletLoading, setWalletLoading] = useState(false);
  const [showAddFunds, setShowAddFunds] = useState(false);
  const [addFundsAmount, setAddFundsAmount] = useState('1000');
  const [addFundsError, setAddFundsError] = useState<string | null>(null);
  const [topupSuccess, setTopupSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    const load = async () => {
      setInvoicesLoading(true);
      const { data, error } = await supabase
        .from('invoices' as any)
        .select('*')
        .eq('client_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);
      if (!error && !cancelled) setInvoices((data || []) as any[]);
      if (!cancelled) setInvoicesLoading(false);
    };
    void load();
    const channel = supabase
      .channel('client-invoices-' + user.id)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'invoices', filter: `client_id=eq.${user.id}` }, () => void load())
      .subscribe();
    return () => { cancelled = true; void supabase.removeChannel(channel); };
  }, [user]);

  const openInvoice = async (invoiceId: string) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;
    const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/invoice?id=${invoiceId}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${session.access_token}` } });
    if (!res.ok) return;
    const blob = await res.blob();
    window.open(URL.createObjectURL(blob), '_blank');
  };

  const fetchTransactions = useCallback(async () => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('transactions')
      .select(`
        *,
        contract:contracts!transactions_contract_id_fkey(
          id,
          project:projects(title)
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      // ⚡ Cap the result — unbounded history loads every transaction ever made
      // (payload grows forever). Latest 200 keeps the page fast; older rows stay
      // available in the wallet/DB for accounting.
      .limit(200);

    if (error) {
      console.error('Error fetching transactions:', error);
    } else {
      setTransactions(data as unknown as Transaction[] || []);
    }
    setLoading(false);
  }, [user?.id]);

  const fetchPaymentMethods = useCallback(async () => {
    setPaymentMethodsLoading(true);
    setPaymentMethodsError(null);
    try {
      const result = await clientPaymentMethodsService.getPaymentMethods();
      if (result.success && result.methods) {
        setPaymentMethods(result.methods);
      } else {
        setPaymentMethodsError(result.error || 'Failed to load payment methods');
      }
    } catch {
      setPaymentMethodsError('Failed to load payment methods');
    } finally {
      setPaymentMethodsLoading(false);
    }
  }, []);

  const fetchSavedCards = useCallback(async () => {
    setSavedCardsLoading(true);
    try {
      const cards = await razorpayService.getSavedCards();
      setSavedCards(cards);
    } catch {
      // Saved cards fetch is non-critical
    } finally {
      setSavedCardsLoading(false);
    }
  }, []);

  /** Fetch the client's wallet balance (used to fund escrow). */
  const fetchWallet = useCallback(async () => {
    if (!user?.id) return;
    setWalletLoading(true);
    try {
      const result = await withdrawalService.getWalletBalance();
      if (result.success && result.balance) {
        setWalletBalance(Number(result.balance.balance) || 0);
      }
    } catch (err) {
      console.error('[wallet] fetchWallet failed:', err);
    } finally {
      setWalletLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchTransactions();
    void fetchPaymentMethods();
    void fetchSavedCards();
    void fetchWallet();

    // Keep wallet balance fresh when a top-up lands (realtime + refresh)
    const walletChannel = supabase
      .channel(`client-wallet-${user?.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wallets', filter: `user_id=eq.${user?.id}` }, () => void fetchWallet())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'transactions', filter: `user_id=eq.${user?.id}` }, () => void fetchWallet())
      .subscribe();

    const subscription = realtimeChannels.transactions(`client-payments-${user?.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${user?.id}` as any,
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            // Dedup by id — realtime can deliver the same INSERT twice;
            // never render duplicate transactions.
            const incoming = payload.new as Transaction;
            setTransactions((prev) =>
              prev.some((t) => t.id === incoming.id) ? prev : [incoming, ...prev]
            );
          } else if (payload.eventType === 'UPDATE') {
            setTransactions((prev) =>
              prev.map((t) => (t.id === payload.new.id ? (payload.new as Transaction) : t))
            );
          }
        }
      )
      .subscribe();

    const paypalSub = supabase
      .channel(`client-paypal-${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'paypal_orders' },
        () => void fetchTransactions()
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
      void paypalSub.unsubscribe();
      void supabase.removeChannel(walletChannel);
    };
  }, [user?.id, fetchTransactions, fetchPaymentMethods, fetchSavedCards, fetchWallet]);

  const handleAddPaymentMethod = async () => {
    if (!user?.id) return;
    setAddingPaymentMethod(true);
    setPaymentMethodsError(null);
    try {
      const formData: {
        type: 'card' | 'paypal' | 'bank_transfer';
        card_last_four?: string | null;
        card_brand?: string | null;
        card_expiry?: string | null;
        paypal_email?: string | null;
        account_holder_name?: string | null;
        account_number_last_four?: string | null;
        bank_name?: string | null;
        is_default?: boolean;
      } = { type: newPaymentMethod.type };

      if (newPaymentMethod.type === 'card') {
        formData.card_last_four = newPaymentMethod.cardLastFour || null;
        formData.card_brand = newPaymentMethod.cardBrand || null;
        formData.card_expiry = newPaymentMethod.cardExpiry || null;
      } else if (newPaymentMethod.type === 'paypal') {
        formData.paypal_email = newPaymentMethod.paypalEmail || null;
      } else if (newPaymentMethod.type === 'bank_transfer') {
        formData.account_holder_name = newPaymentMethod.accountHolderName || null;
        formData.account_number_last_four = newPaymentMethod.accountNumberLastFour || null;
        formData.bank_name = newPaymentMethod.bankName || null;
      }

      if (paymentMethods.length === 0 || newPaymentMethod.isDefault) {
        formData.is_default = true;
      }

      const result = await clientPaymentMethodsService.addPaymentMethod(formData);
      if (!result.success) {
        setPaymentMethodsError(result.error || 'Failed to add payment method');
        return;
      }

      setShowAddPaymentMethod(false);
      setNewPaymentMethod({
        type: 'card',
        cardLastFour: '',
        cardBrand: '',
        cardExpiry: '',
        paypalEmail: '',
        accountHolderName: '',
        accountNumberLastFour: '',
        bankName: '',
        isDefault: false,
      });
      void fetchPaymentMethods();
    } catch {
      setPaymentMethodsError('Failed to add payment method');
    } finally {
      setAddingPaymentMethod(false);
    }
  };

  const handleRemovePaymentMethod = async (id: string) => {
    if (!user?.id) return;
    setDeletingPaymentMethodId(id);
    setPaymentMethodsError(null);
    try {
      const result = await clientPaymentMethodsService.deletePaymentMethod(id);
      if (!result.success) {
        setPaymentMethodsError(result.error || 'Failed to delete payment method');
        return;
      }
      void fetchPaymentMethods();
    } catch {
      setPaymentMethodsError('Failed to delete payment method');
    } finally {
      setDeletingPaymentMethodId(null);
      setConfirmDeletePaymentMethod(null);
    }
  };

  const handleSetDefaultPaymentMethod = async (id: string) => {
    setPaymentMethodsError(null);
    try {
      const result = await clientPaymentMethodsService.setDefaultPaymentMethod(id);
      if (!result.success) {
        setPaymentMethodsError(result.error || 'Failed to set default payment method');
        return;
      }
      void fetchPaymentMethods();
    } catch {
      setPaymentMethodsError('Failed to set default payment method');
    }
  };

  const filteredTransactions = transactions.filter((t) =>
    filter === 'all' ? true : t.type === filter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-emerald-100 text-emerald-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'failed':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'escrow':
        return <CreditCard className="w-4 h-4" />;
      case 'withdrawal':
        return <ArrowUpRight className="w-4 h-4" />;
      case 'deposit':
        return <ArrowDownLeft className="w-4 h-4" />;
      default:
        return <IndianRupee className="w-4 h-4" />;
    }
  };

  const formatAmount = (amount: number, type: string) => {
    return `${type === 'credit' ? '+' : '-'}${formatCurrency(safeNumber(Math.abs(amount)))}`;
  };

  const formatInvoiceAmount = (amount: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount || 0);

  const exportCsv = () => {
    const rows = [
      ['Date', 'Type', 'Source', 'Amount', 'Status', 'Description'],
      ...filteredTransactions.map((t) => [
        t.created_at ? new Date(t.created_at).toISOString() : '',
        t.type,
        t.source,
        String(t.amount),
        t.status,
        t.description || '',
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `growlancer-payments-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return <PageSkeleton />;
  }

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 flex-shrink-0">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-xl font-bold text-slate-900 flex items-center gap-2 flex-wrap">Payments <InfoTip title="How your money moves on Growlanzo" text="Fund escrow from your wallet or card before work starts — money is held safely and only released to the freelancer after you approve the completed work. Every transaction is recorded here in real time, and invoices are generated automatically when escrow is released." /></h1>
          <p className="text-slate-500 mt-1">Manage your transactions, wallet, and payment methods</p>
          </div>
        </div>
        <Link
          to="/client/workspace?fund=1"
          className="inline-flex items-center justify-center gap-3 px-3 py-3 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700 transition-all flex-shrink-0"
        >
          <Plus className="w-4 h-4" />
          Fund Escrow
        </Link>
      </div>

      {/* Wallet — add funds to test the escrow workflow */}
      <div className="bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-600 rounded-xl p-6 text-white shadow-lg shadow-emerald-600/20 relative overflow-hidden">
        <div className="absolute -right-8 -top-8 w-40 h-40 bg-white/10 rounded-full" />
        <div className="absolute right-10 bottom-4 w-6 h-6 bg-white/10 rounded-full" />
        <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 relative">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-8 h-8 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
              <Wallet className="w-7 h-7 text-white" />
            </div>
            <div>
              <p className="text-emerald-100 text-xs font-medium uppercase tracking-widest flex items-center gap-1.5">
                Wallet Balance
                <InfoTip
                  text="Money you've added to your Growlanzo wallet. Use it to fund escrow instantly — funds never expire and are fully refundable if no work has started."
                  title="Wallet Balance"
                  align="left"
                  tone="emerald"
                  className="[&_svg]:text-emerald-100 [&_svg]:hover:text-white"
                />
              </p>
              <div className="flex items-center gap-1.5">
                <p className="text-xl font-bold mt-1">
                  {walletLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-emerald-100 inline" />
                  ) : (
                    formatCurrency(walletBalance)
                  )}
                </p>
                <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full font-medium">INR</span>
              </div>
              <p className="text-emerald-100/90 text-sm mt-1">
                Use your wallet to fund escrow — no card needed each time
              </p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-1.5">
            <button
              onClick={() => {
                setAddFundsError(null);
                setTopupSuccess(null);
                setShowAddFunds(true);
              }}
              className="inline-flex items-center justify-center gap-3 px-3 py-3 bg-white text-emerald-700 font-bold rounded-xl hover:bg-emerald-50 transition-all shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              Add Funds
            </button>
            <a
              href="#wallet-txn"
              className="inline-flex items-center justify-center gap-3 px-3 py-3 bg-white/15 hover:bg-white/25 text-white font-semibold rounded-xl transition-all"
            >
              <ArrowDownLeft className="w-4 h-4" />
              Wallet Activity
            </a>
          </div>
        </div>
      </div>

      {/* Add Funds Modal */}
      {showAddFunds && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setShowAddFunds(false)}
          />
          <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 pb-0">
              <h2 className="font-display text-xl font-bold text-slate-900">Add Funds to Wallet</h2>
              <button
                onClick={() => setShowAddFunds(false)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-3">
              <p className="text-sm text-slate-500 mb-2">
                Add money to your Growlanzo wallet, then fund escrow instantly from it.
              </p>

              {addFundsError && (
                <div className="mb-2 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-red-700">{addFundsError}</p>
                </div>
              )}
              {topupSuccess && (
                <div className="mb-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                  <p className="text-sm text-emerald-700">{topupSuccess}</p>
                </div>
              )}

              <label className="block text-sm font-medium text-slate-700 mb-2">Amount ({currencySymbol()})</label>
              <div className="relative mb-1.5">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">{currencySymbol()}</span>
                <input
                  type="number"
                  min={50}
                  max={100000}
                  value={addFundsAmount}
                  onChange={(e) => setAddFundsAmount(e.target.value)}
                  className="w-full pl-8 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  placeholder="1000"
                />
              </div>
              <div className="flex items-center gap-3 mb-2.5">
                {[500, 1000, 2500, 5000, 10000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setAddFundsAmount(String(amt))}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                      Number(addFundsAmount) === amt
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    {formatCurrency(amt)}
                  </button>
                ))}
              </div>

              {/* Mirror the server-side bounds (razorpay edge fn: ₹50–₹1,00,000) so the
                  user gets instant feedback instead of a checkout error later. */}
              {(() => {
                const amtNum = Number(addFundsAmount);
                const invalid = addFundsAmount !== '' && (!Number.isFinite(amtNum) || amtNum < 50 || amtNum > 100000);
                if (!invalid) return null;
                return (
                  <p className="text-xs text-red-600 mb-2">Amount must be between ₹50 and ₹1,00,000.</p>
                );
              })()}

              {(() => {
                const amtNum = Number(addFundsAmount);
                const valid = addFundsAmount !== '' && Number.isFinite(amtNum) && amtNum >= 50 && amtNum <= 100000;
                if (!valid) return null;
                return (
                  <RazorpayCheckout
                    orderData={{
                      order_type: 'wallet_topup',
                      amount: amtNum,
                      currency: 'INR',
                      description: 'Growlanzo wallet top-up',
                    }}
                    onSuccess={() => {
                      setTopupSuccess('Funds added! Your wallet has been credited.');
                      setShowAddFunds(false);
                      // Immediate refresh + delayed retries (edge function may still be
                      // processing the verify_payment → wallet credit chain)
                      void fetchWallet();
                      void fetchTransactions();
                      setTimeout(() => void fetchWallet(), 2000);
                      setTimeout(() => void fetchWallet(), 5000);
                    }}
                    onError={(e) => {
                      setAddFundsError(e.message || 'Payment failed. Please try again.');
                    }}
                    buttonText={`Pay ${formatCurrency(amtNum)} with Razorpay`}
                    userInfo={{ name: (user as any)?.user_metadata?.name, email: user?.email }}
                  />
                );
              })()}

              <div className="mt-4 p-3 bg-slate-50 rounded-xl">
                <p className="text-xs text-slate-500 flex items-center gap-3">
                  <Shield className="w-4 h-4 text-emerald-600 shrink-0" />
                  Payments are processed securely by Razorpay. Wallet funds never expire and can be used to fund escrow on any contract.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-1.5">
        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 text-xs font-bold uppercase tracking-widest">
              Total Spent
            </h3>
            <div className="h-10 w-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
              <IndianRupee className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-bold tracking-tight">
            {formatCurrency(
              transactions
                .filter((t) => t.type === 'debit' && t.status === 'completed')
                .reduce((sum, t) => sum + t.amount, 0)
            )}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 text-xs font-bold uppercase tracking-widest">
              In Escrow
            </h3>
            <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-bold tracking-tight">
            {formatCurrency(
              transactions
                .filter((t) => t.source === 'escrow' && t.status === 'pending')
                .reduce((sum, t) => sum + t.amount, 0)
            )}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 text-xs font-bold uppercase tracking-widest">
              Refunds
            </h3>
            <div className="h-10 w-10 rounded-xl bg-orange-50 flex items-center justify-center text-orange-600">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-bold tracking-tight">
            {formatCurrency(
              transactions
                .filter((t) => t.source === 'refund' && t.status === 'completed')
                .reduce((sum, t) => sum + t.amount, 0)
            )}
          </p>
        </div>
      </div>

      {/* ===== Razorpay Saved Cards Section ===== */}
      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-xl font-bold text-slate-900 flex items-center gap-3">
            <Shield className="w-4 h-4 text-emerald-600" />
            Saved Payment Cards
          </h2>
        </div>

        {/* Loading */}
        {savedCardsLoading && (
          <div className="flex items-center justify-center py-3">
            <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
            <span className="ml-2 text-sm text-slate-500">Loading saved cards...</span>
          </div>
        )}

        {/* Saved cards list */}
        {!savedCardsLoading && savedCards.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mb-3">
            {savedCards.map((card) => (
              <div
                key={card.id}
                className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:border-emerald-300 transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <CreditCard className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="font-medium text-slate-900 text-sm">
                        {card.card_network || 'Card'} •••• {card.card_last_four}
                      </span>
                      <span className="ml-2 text-xs bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded font-medium uppercase">
                        {card.card_type || 'Card'}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      setDeletingSavedCardId(card.card_id);
                      try {
                        await razorpayService.deleteSavedCard(card.card_id);
                        await fetchSavedCards();
                      } catch { /* ignore */ }
                      setDeletingSavedCardId(null);
                    }}
                    disabled={deletingSavedCardId === card.card_id}
                    className="text-slate-400 hover:text-red-500 transition-colors"
                    title="Remove saved card"
                  >
                    {deletingSavedCardId === card.card_id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <div className="text-xs text-slate-500 space-y-0.5">
                  {card.card_expiry_month && card.card_expiry_year && (
                    <p>Expires {card.card_expiry_month}/{card.card_expiry_year}</p>
                  )}
                  {card.card_holder_name && <p>{card.card_holder_name}</p>}
                  {card.last_used_at && (
                    <p>Last used {safeFormatDate(card.last_used_at)}</p>
                  )}
                  <p>Used {card.used_count} time{card.used_count !== 1 ? 's' : ''}</p>
                </div>

                <div className="mt-3 p-2 bg-emerald-50 rounded-lg border border-emerald-100">
                  <p className="text-xs text-emerald-700 font-medium flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" />
                    One-click pay enabled — cards are tokenized via Razorpay
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        {!savedCardsLoading && savedCards.length === 0 && (
          <div className="text-center py-4 text-slate-500 mb-2">
            <Shield className="w-8 h-8 mx-auto mb-3 text-slate-300" />
            <p className="font-medium">No saved cards yet</p>
            <p className="text-sm mt-1">Save a card during your next escrow payment for one-click checkout</p>
          </div>
        )}

        <div className="h-px bg-slate-200 my-4" />

        {/* ===== Manual Payment Method References ===== */}
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-display text-base font-bold text-slate-900 flex items-center gap-3">
            <CreditCard className="w-4 h-4 text-slate-400" />
            Payment Method References
          </h3>
          {!showAddPaymentMethod && (
            <button
              onClick={() => setShowAddPaymentMethod(true)}
              className="inline-flex items-center justify-center gap-3 px-4 py-2.5 bg-emerald-600 text-white text-sm font-medium rounded-xl hover:bg-emerald-700 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              Add Reference
            </button>
          )}
        </div>

        {/* Loading */}
        {paymentMethodsLoading && (
          <div className="flex items-center justify-center py-3">
            <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
            <span className="ml-2 text-sm text-slate-500">Loading payment methods...</span>
          </div>
        )}

        {/* Error */}
        {paymentMethodsError && (
          <div className="p-4 bg-red-50 border border-red-200 rounded-xl mb-2 flex items-center gap-3">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
            <p className="text-sm text-red-700">{paymentMethodsError}</p>
            <button
              onClick={() => void fetchPaymentMethods()}
              className="ml-auto text-xs text-red-600 hover:text-red-800 font-medium underline"
            >
              Retry
            </button>
          </div>
        )}

        {/* Method list */}
        {!paymentMethodsLoading && paymentMethods.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mb-2">
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className={`p-4 rounded-xl border transition-all ${
                  method.is_default
                    ? 'border-emerald-300 bg-emerald-50/50'
                    : 'border-slate-200 bg-slate-50/50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    {method.type === 'card' ? (
                      <CreditCard className="w-4 h-4 text-blue-600" />
                    ) : method.type === 'paypal' ? (
                      <IndianRupee className="w-4 h-4 text-blue-500" />
                    ) : (
                      <Building2 className="w-4 h-4 text-green-600" />
                    )}
                    <span className="font-medium text-slate-900 text-sm capitalize">{method.type.replace('_', ' ')}</span>
                    {method.is_default && (
                      <span className="text-xs bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded font-medium">
                        Default
                      </span>
                    )}
                  </div>
                  {/* Confirm delete inline */}
                  {confirmDeletePaymentMethod === method.id ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleRemovePaymentMethod(method.id)}
                        disabled={deletingPaymentMethodId === method.id}
                        className="text-xs px-2 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium disabled:opacity-50"
                      >
                        {deletingPaymentMethodId === method.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          'Confirm'
                        )}
                      </button>
                      <button
                        onClick={() => setConfirmDeletePaymentMethod(null)}
                        className="text-xs px-2 py-1 bg-slate-200 text-slate-600 rounded-lg hover:bg-slate-300 font-medium"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmDeletePaymentMethod(method.id)}
                      className="text-slate-400 hover:text-red-500 transition-colors"
                      title="Remove payment method"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="text-sm text-slate-600 space-y-0.5">
                  {method.type === 'card' && (
                    <>
                      <p className="font-medium text-slate-800">
                        {method.card_brand ? `${method.card_brand} •••• ${method.card_last_four}` : `•••• ${method.card_last_four}`}
                      </p>
                      {method.card_expiry && <p className="text-xs">Expires {method.card_expiry}</p>}
                    </>
                  )}
                  {method.type === 'paypal' && (
                    <p className="font-medium text-slate-800">{method.paypal_email}</p>
                  )}
                  {method.type === 'bank_transfer' && (
                    <>
                      <p className="font-medium text-slate-800">{method.bank_name || 'Bank Account'}</p>
                      <p className="text-xs">
                        {method.account_holder_name ? `${method.account_holder_name} — ` : ''}
                        •••• {method.account_number_last_four}
                      </p>
                    </>
                  )}
                </div>

                {!method.is_default && (
                  <button
                    onClick={() => handleSetDefaultPaymentMethod(method.id)}
                    className="mt-2 text-xs text-emerald-600 hover:text-emerald-700 font-medium"
                  >
                    Set as Default
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {!paymentMethodsLoading && paymentMethods.length === 0 && !showAddPaymentMethod && (
          <div className="text-center py-4 text-slate-500">
            <CreditCard className="w-8 h-8 mx-auto mb-3 text-slate-300" />
            <p className="font-medium">No payment method references saved</p>
            <p className="text-sm mt-1">Add a payment method for record-keeping purposes</p>
          </div>
        )}

        {/* Add Payment Method Form */}
        {showAddPaymentMethod && (
          <div className="p-4 border-2 border-dashed border-slate-200 rounded-xl">
            <h3 className="font-medium text-slate-900 mb-2">Add Payment Method</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Method Type</label>
                <select
                  value={newPaymentMethod.type}
                  onChange={(e) => {
                    // PayPal is Coming Soon — never allow saving a PayPal reference
                    if (e.target.value === 'paypal') return;
                    setNewPaymentMethod({
                      ...newPaymentMethod,
                      type: e.target.value as 'card' | 'paypal' | 'bank_transfer',
                    });
                  }}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                >
                  <option value="card">Credit / Debit Card</option>
                  <option value="paypal" disabled>PayPal (Coming Soon)</option>
                  <option value="bank_transfer">Bank Account</option>
                </select>
              </div>

              {newPaymentMethod.type === 'card' && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Card Brand</label>
                      <input
                        type="text"
                        value={newPaymentMethod.cardBrand}
                        onChange={(e) =>
                          setNewPaymentMethod({ ...newPaymentMethod, cardBrand: e.target.value })
                        }
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                        placeholder="Visa, Mastercard..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Last 4 Digits</label>
                      <input
                        type="text"
                        maxLength={4}
                        value={newPaymentMethod.cardLastFour}
                        onChange={(e) =>
                          setNewPaymentMethod({ ...newPaymentMethod, cardLastFour: e.target.value })
                        }
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                        placeholder="1234"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Expiry Date</label>
                    <input
                      type="text"
                      value={newPaymentMethod.cardExpiry}
                      onChange={(e) =>
                        setNewPaymentMethod({ ...newPaymentMethod, cardExpiry: e.target.value })
                      }
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      placeholder="MM/YY"
                    />
                  </div>
                </>
              )}

              {newPaymentMethod.type === 'paypal' && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">PayPal Email</label>
                  <input
                    type="email"
                    value={newPaymentMethod.paypalEmail}
                    onChange={(e) =>
                      setNewPaymentMethod({ ...newPaymentMethod, paypalEmail: e.target.value })
                    }
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    placeholder="your@email.com"
                  />
                </div>
              )}

              {newPaymentMethod.type === 'bank_transfer' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Account Holder Name</label>
                    <input
                      type="text"
                      value={newPaymentMethod.accountHolderName}
                      onChange={(e) =>
                        setNewPaymentMethod({ ...newPaymentMethod, accountHolderName: e.target.value })
                      }
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Bank Name</label>
                      <input
                        type="text"
                        value={newPaymentMethod.bankName}
                        onChange={(e) =>
                          setNewPaymentMethod({ ...newPaymentMethod, bankName: e.target.value })
                        }
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">Last 4 Digits</label>
                      <input
                        type="text"
                        maxLength={4}
                        value={newPaymentMethod.accountNumberLastFour}
                        onChange={(e) =>
                          setNewPaymentMethod({ ...newPaymentMethod, accountNumberLastFour: e.target.value })
                        }
                        className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none transition-all"
                        placeholder="1234"
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="makeDefault"
                  checked={newPaymentMethod.isDefault}
                  onChange={(e) =>
                    setNewPaymentMethod({ ...newPaymentMethod, isDefault: e.target.checked })
                  }
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                />
                <label htmlFor="makeDefault" className="text-sm text-slate-700">
                  Set as default payment method
                </label>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowAddPaymentMethod(false);
                    setPaymentMethodsError(null);
                  }}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 font-medium rounded-xl hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddPaymentMethod}
                  disabled={addingPaymentMethod}
                  className="flex-1 flex items-center justify-center gap-3 px-4 py-3 bg-emerald-600 text-white font-medium rounded-xl hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {addingPaymentMethod ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <PlusCircle className="w-4 h-4" />
                  )}
                  {addingPaymentMethod ? 'Adding...' : 'Save Method'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      <div id="wallet-txn" className="flex items-center gap-3 border-b border-slate-200">
        {(['all', 'credit', 'debit'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 font-medium transition-colors ${
              filter === f
                ? 'text-emerald-600 border-b-2 border-emerald-600'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
        <button className="ml-auto flex items-center gap-3 px-4 py-2 text-slate-600 font-medium rounded-lg hover:bg-slate-50 transition-colors">
          <Filter className="w-4 h-4" />
          Filter
        </button>
        <button
          type="button"
          onClick={exportCsv}
          className="flex items-center gap-3 px-4 py-2 text-slate-600 font-medium rounded-lg hover:bg-slate-50 transition-colors"
        >
          <Download className="w-4 h-4" />
          Export
        </button>
      </div>

      {/* Transactions List */}
      {filteredTransactions.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-xl border border-slate-100">
          <div className="w-20 h-20 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-2.5">
            <CreditCard className="w-7 h-7 text-slate-300" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">
            {filter === 'all' ? 'No transactions yet' : `No ${filter} transactions`}
          </h3>
          <p className="text-slate-500 max-w-sm mx-auto mb-3">
            {filter === 'all'
              ? 'When you fund escrow for a contract or make payments, your transaction history will appear here.'
              : `You don't have any ${filter} transactions at the moment.`}
          </p>
          {filter === 'all' && (
            <Link
              to="/client/contracts"
              className="inline-flex items-center justify-center gap-3 px-3 py-3 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700 transition-all"
            >
              <FileText className="w-4 h-4" />
              View Contracts
            </Link>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-100">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  <th className="text-left px-3 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Transaction
                  </th>
                  <th className="text-left px-3 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="text-left px-3 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="text-right px-3 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Amount
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-3 py-4">
                      <div className="flex items-center gap-1.5">
                        <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600">
                          {getSourceIcon(transaction.source)}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">
                            {transaction.description || transaction.source}
                          </p>
                          {transaction.contract?.project && (
                            <p className="text-sm text-slate-500">
                              {transaction.contract.project.title}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-4 text-sm text-slate-600">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-4 h-4" />
                        {safeFormatDate(transaction.created_at)}
                      </div>
                    </td>
                    <td className="px-3 py-4">
                      <span
                        className={`px-3 py-1 text-xs font-bold uppercase rounded-full ${getStatusColor(
                          transaction.status
                        )}`}
                      >
                        {transaction.status}
                      </span>
                    </td>
                    <td className="px-3 py-4 text-right">
                      <span
                        className={`font-bold ${
                          transaction.type === 'credit' ? 'text-emerald-600' : 'text-slate-900'
                        }`}
                      >
                        {formatAmount(transaction.amount, transaction.type)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Invoices & Receipts — auto-generated on escrow release */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm">
        <div className="p-3 border-b border-slate-100 flex items-center justify-between gap-3">
          <div>
            <h3 className="font-display text-xl font-bold text-slate-900">Invoices & Receipts</h3>
            <p className="text-sm text-slate-500 mt-0.5">Tax-ready invoices generated automatically when escrow is released</p>
          </div>
          {invoicesLoading && <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />}
        </div>
        {invoices.length === 0 && !invoicesLoading ? (
          <div className="p-12 text-center text-slate-400">
            <FileText className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p className="text-sm">No invoices yet — they appear here once you release escrow on a contract.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {invoices.map((inv: any) => (
              <div key={inv.id} className="p-5 flex items-center justify-between gap-3 hover:bg-slate-50/60 transition-colors">
                <div className="flex items-center gap-1.5 min-w-0">
                  <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 text-sm">{inv.invoice_number}</p>
                    <p className="text-xs text-slate-500">{inv.project_title || 'Contract work'}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{safeFormatDate(inv.issued_at)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <div className="text-right">
                    <p className="font-bold text-slate-900">{formatInvoiceAmount(inv.total)}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold uppercase ${inv.status === 'paid' ? 'bg-emerald-50 text-emerald-700' : inv.status === 'refunded' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-700'}`}>
                      {inv.status}
                    </span>
                  </div>
                  <button
                    onClick={() => void openInvoice(inv.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    <Download className="w-4 h-4" /> View / PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}