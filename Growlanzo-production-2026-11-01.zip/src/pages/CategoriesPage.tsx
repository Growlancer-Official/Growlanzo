import { Link } from 'react-router-dom';
import { AlertCircle, ArrowRight, Layers, Loader2 } from 'lucide-react';
import { useCategories } from '../hooks/useCategories';
import { CategoriesSection } from '../components/CategoriesSection';
import { TipNote } from '../components/TipNote';
import { BrandLogo } from '../components/BrandLogo';

export function CategoriesPage() {
  const { categories, loading, error, refresh } = useCategories();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Premium Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-40 border-b border-slate-200/50">
        <div className="mx-auto max-w-[100rem] px-4 sm:px-6 lg:px-8 2xl:px-12 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <BrandLogo variant="wordmark" className="h-8 sm:h-9 transition-transform group-hover:scale-105 w-auto" />
          </Link>
          <Link to="/" className="inline-block py-1 text-sm font-medium text-slate-500 hover:text-slate-900 transition-colors">
            Back to Home
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="py-5 sm:py-14">
        <div className="mx-auto max-w-[100rem] px-4 sm:px-6 lg:px-8 2xl:px-12 text-center">
          <div className="inline-flex items-center gap-3 px-3 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold uppercase tracking-wider rounded-full mb-3">
            <Layers className="w-4 h-4" />
            {loading ? '...' : categories.length} Categories
          </div>
          <h1 className="font-display text-4xl sm:text-5xl font-bold text-slate-900 mb-3">
            Browse All Categories
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Explore all {loading ? '...' : categories.length} categories — from Development & IT to Sustainability. 
            Browse all categories and find the right freelancer for your project.
          </p>
          <TipNote tone="info" className="mt-6 max-w-2xl mx-auto text-left">
            Every category connects you to vetted freelancers with real ratings, verified badges and escrow-protected
            payments — no matter which skill you need, hiring stays safe and inside Growlanzo.
          </TipNote>
        </div>
      </section>

      {/* Categories Section */}
      <section className="pb-16 sm:pb-20">
        <div className="mx-auto max-w-[100rem] px-4 sm:px-6 lg:px-8 2xl:px-12">
          {/* Error banner */}
          {error && !loading && (
            <div className="mb-2 flex items-center gap-3 px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-700 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>Could not load live category data. Categories are still browseable below.</span>
              <button
                onClick={refresh}
                className="ml-auto text-xs font-medium text-amber-700 underline hover:text-amber-800 whitespace-nowrap"
              >
                Retry
              </button>
            </div>
          )}

          {loading && categories.length === 0 ? (
            <div className="flex items-center justify-center py-10">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
            </div>
          ) : (
            <CategoriesSection mode="browse" maxInitial={0} />
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="pb-16 sm:pb-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 2xl:px-12">
          <div className="bg-white rounded-[2.5rem] p-4 sm:p-12 text-center border border-slate-200 shadow-sm">
            <h2 className="font-display text-3xl font-bold text-slate-900 mb-2">Can't find what you're looking for?</h2>
            <p className="text-slate-600 mb-2 max-w-lg mx-auto">
              Post a custom project and let our AI match you with the perfect freelancer for your specific needs.
            </p>
            <Link
              to="/signup"
              className="inline-flex items-center justify-center gap-3 h-12 px-8 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 transition-colors"
            >
              Post a Custom Project
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
