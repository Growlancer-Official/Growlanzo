import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Globe, Heart, Quote, ShieldCheck, Sparkles, Star, Target, TrendingUp, Users, Zap } from 'lucide-react';
import { LiveCodeTerminal, type TerminalLine } from '@/components/LiveCodeTerminal';
import { useAboutPageMetrics } from '@/hooks/useAboutPageMetrics';
import { formatCurrency } from '@/lib/currency';
import { isFeatureEnabled } from '@/lib/featureFlags';
import { BrandLogo } from '../components/BrandLogo';

function formatInrFull(inr: number): string {
  if (!Number.isFinite(inr) || inr < 0) return formatCurrency(0);
  return formatCurrency(Math.round(inr));
}

export function AboutPage() {
  const { stats, ready, raw, refresh } = useAboutPageMetrics();

  // Real content — inject live platform numbers into the terminal script. Every
  // value here comes from the database (RPC + live counts) and re-renders on the
  // realtime subscriptions, so each typing cycle prints fresh numbers.
  const terminalLines = useMemo<TerminalLine[]>(() => {
    const members = raw.members != null ? raw.members.toLocaleString('en-US') : '—';
    const escrow = raw.escrowInr != null ? formatInrFull(raw.escrowInr) : formatCurrency(0);
    const countries = raw.countries != null ? raw.countries.toLocaleString('en-US') : '—';
    const reviews = raw.totalReviews ?? 0;
    // Satisfaction is only meaningful from 5 reviews up; before that say so
    // honestly instead of printing a dash that looks broken.
    const satisfaction =
      reviews >= 5 && raw.satisfactionPercent != null
        ? `${Math.round(raw.satisfactionPercent)}% satisfaction`
        : 'no ratings yet';
    const syncedAt = raw.syncedAt
      ? raw.syncedAt.toLocaleTimeString('en-IN', {
          hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
        })
      : '—';
    return [
      [{ text: `// Real-Time Canvas Synced Init · live DB @ ${syncedAt}`, className: 'text-emerald-600' }],
      [
        { text: 'const workspace = await Growlanzo.createWorkspace(contractId);' },
        { text: `  // ${members} registered members · ${countries} countries`, className: 'text-slate-400' },
      ],
      [
        { text: 'await workspace.mountKanbanBoard();' },
        { text: '  // tasks sync in real time', className: 'text-slate-400' },
      ],
      [{ text: 'await workspace.mountScratchpad({ focusLock: true });' }],
      [
        { text: 'await workspace.escrow.verifyFunding();', className: 'text-amber-500' },
        { text: `  // ${escrow} protected in escrow`, className: 'text-slate-400' },
      ],
      [
        {
          text: `// ${satisfaction} · ${countries} countries — ready to co-work seamlessly!`,
          className: 'text-slate-400',
        },
      ],
    ];
  }, [raw]);

  const values = [
    {
      icon: Target,
      title: 'AI Precision Matching',
      desc: 'No more generic bidding pools. Our multi-variable semantic matching aligns the exact freelancer skills with the client project guidelines in seconds.',
      color: 'from-emerald-500/10 to-teal-500/10',
      iconColor: 'text-emerald-600 bg-emerald-100',
    },
    {
      icon: Heart,
      title: 'Escrow-First Trust',
      desc: 'Complete payment security. Funds are safely locked in virtual pools at contract launch and released programmatically only when deliverables are verified.',
      color: 'from-amber-500/10 to-orange-500/10',
      iconColor: 'text-amber-600 bg-amber-100',
    },
    {
      icon: Globe,
      title: 'Real-Time Co-Working',
      desc: 'Work borders are obsolete. Our system bridges team coordinates across distances, providing micro-second syncing of tasks, note scratchpads, and secure assets.',
      color: 'from-emerald-500/10 to-teal-500/10',
      iconColor: 'text-emerald-600 bg-emerald-100',
    },
    {
      icon: Users,
      title: 'Active Community',
      desc: 'Growlanzo treats freelancers and clients as mutual stakeholders. Symmetrical platform fees and verified expert badges empower sustainable careers.',
      color: 'from-orange-500/10 to-amber-500/10',
      iconColor: 'text-orange-600 bg-orange-100',
    },
  ];

  return (
    <div className="min-h-screen bg-cream font-sans pb-24 text-slate-800">
      {/* Symmetrical Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-40 border-b border-slate-200/50">
        <div className="mx-auto max-w-[100rem] px-4 sm:px-6 lg:px-8 2xl:px-12 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo variant="wordmark" className="h-8 sm:h-9 w-auto" />
          </Link>
          <Link
            to="/"
            className="flex items-center gap-1.5 py-1 text-sm font-bold text-slate-600 hover:text-emerald-600 transition-colors"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            Back to Home
          </Link>
        </div>
      </header>

      {/* Hero section */}
      <section className="relative py-10 sm:py-28 overflow-hidden bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white border-b border-emerald-900/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-500/5 rounded-full blur-3xl -ml-20 -mb-20"></div>

        <div className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 2xl:px-12 text-center space-y-3">
          <span className="inline-flex items-center gap-3 px-3 py-1 bg-emerald-500/20 text-emerald-300 font-bold rounded-full border border-emerald-500/30 text-xs uppercase tracking-wider">
            <Sparkles className="w-4 h-4 animate-pulse" />
            Our Mission
          </span>
          <h1 className="font-display text-4xl sm:text-6xl font-black tracking-tight leading-none">
            We are building the <br />
            <span className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">Future of Professional Work</span>
          </h1>
          <p className="text-slate-300 text-base sm:text-lg max-w-2xl mx-auto font-medium leading-relaxed">
            Growlanzo eliminates the coordination gaps that plague legacy platforms. By combining intelligent semantic matching with integrated, real-time workspace canvases, we make remote collaboration direct, secure, and delightful.
          </p>
        </div>
      </section>

      {/* Stats Panel */}
      <section className="relative -mt-10 z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12">
        <div className="bg-white rounded-[2.5rem] border border-slate-200/60 p-4 sm:p-10 shadow-xl">
          <div className="text-center space-y-4 mb-2">
            <h2 className="text-xs font-black uppercase text-emerald-600 tracking-widest flex items-center justify-center gap-1.5">
              <TrendingUp className="w-4 h-4" /> Live Platform Metrics
            </h2>
            <p className="text-slate-500 text-xs max-w-md mx-auto">
              Our registered member counter tracks live signups directly from Supabase. Escrow amounts and partner totals update in real time.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {stats.map((stat, index) => (
              <div
                key={index}
                className={`bg-cream/45 rounded-xl p-3 border border-slate-100 flex flex-col justify-between items-center text-center transition-all hover:scale-102 hover:shadow-md ${
                  !ready ? 'animate-pulse' : ''
                }`}
              >
                <div>
                  <span className="font-display text-3xl sm:text-4xl font-black text-slate-900 leading-none tracking-tight tabular-nums">
                    {stat.value}
                  </span>
                </div>
                <div className="text-xs text-slate-500 font-bold mt-3 leading-snug max-w-[12rem]">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Narrative */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 mt-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
          <div className="space-y-3">
            <span className="inline-flex items-center gap-1 text-xs font-black uppercase text-emerald-600 tracking-wider">
              <Zap className="w-4 h-4" /> Bridging the Gaps
            </span>
            <h3 className="font-display text-3xl font-black text-slate-900 leading-tight">
              Why we started Growlanzo
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Traditional freelancing platforms like Upwork and Fiverr have failed to adapt. They force clients and freelancers to coordinate across fragmented third-party tools—bumping from static chat screens to external Kanban boards, separate scratchpads, and disconnected asset storage lockers.
            </p>
            <p className="text-slate-600 text-sm leading-relaxed">
              We built Growlanzo to consolidate this flow. In our system, the contract dashboard <strong>is</strong> the collaborative workspace. When a service is purchased or a milestone funds, a gorgeous glassmorphic canvas instantly spins up with multi-second syncing, task controls, welcome templates, and structured escrow release locks.
            </p>
          </div>
          <div className="relative overflow-hidden">
            {/* decorative glow: clipped so its rotated bounding box can never push
                past the viewport edge on mobile (element-audit group `public`) */}
            <div className="pointer-events-none absolute inset-0 bg-emerald-600/10 rounded-[3rem] blur-3xl -rotate-6"></div>
            <div className="relative bg-white rounded-[3rem] p-4 border border-slate-200/50 shadow-lg space-y-4">
              <div className="flex gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-red-400"></span>
                <span className="w-3.5 h-3.5 rounded-full bg-yellow-400"></span>
                <span className="w-3.5 h-3.5 rounded-full bg-green-400"></span>
              </div>
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/30 text-xs font-mono text-slate-600">
                {/* Each pass re-reads the live numbers, so the canvas never replays
                    a stale snapshot — a new signup or escrow release shows up on the
                    next cycle. */}
                <LiveCodeTerminal lines={terminalLines} className="space-y-4" onCycle={refresh} />
              </div>
              <div className="flex items-center gap-3 bg-emerald-50 rounded-xl p-4 border border-emerald-100">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <span className="text-xs font-bold text-emerald-800">
                  Escrow-protected payments — IP transfers to the client on final release.
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 mt-20 sm:mt-28">
        {/* Section Label */}
        <div className="text-center space-y-3 mb-10 sm:mb-14">
          <span className="inline-flex items-center gap-3 px-4 py-1.5 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-600 font-bold rounded-full border border-emerald-500/20 text-xs uppercase tracking-wider">
            <Star className="w-4 h-4" fill="currentColor" />
            Leadership &amp; Vision
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Meet the Founder
          </h2>
          <p className="text-slate-500 text-sm max-w-lg mx-auto">
            The driving force behind Growlanzo's mission to transform how the world works.
          </p>
        </div>

        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-[1.25rem] sm:rounded-[2rem] p-[1.5px] shadow-xl shadow-slate-900/30">
          <div className="bg-[#0B1120] rounded-[calc(1.25rem-1.5px)] sm:rounded-[calc(2rem-1.5px)] p-3 sm:p-4 md:p-10 relative overflow-hidden">
            {/* Decorative background */}
            <div className="absolute top-0 right-0 w-[300px] sm:w-[500px] h-[300px] sm:h-[500px] bg-gradient-to-br from-emerald-500/5 to-teal-500/5 rounded-full blur-3xl -mr-40 -mt-40"></div>
            <div className="absolute bottom-0 left-0 w-[200px] sm:w-[400px] h-[200px] sm:h-[400px] bg-gradient-to-tr from-emerald-600/5 to-teal-600/5 rounded-full blur-3xl -ml-32 -mb-32"></div>
            <div className="hidden sm:block absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMxMEI5ODEiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>

            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-5 gap-3 lg:gap-10 items-center">
              {/* Founder Image — Left Side */}
              <div className="lg:col-span-2 flex justify-center lg:justify-end">
                <div className="relative">
                  {/* Image Container — Clean & Professional */}
                  <div className="w-56 h-64 sm:w-60 sm:h-72 md:w-72 md:h-80 rounded-xl overflow-hidden border border-white/10 shadow-2xl shadow-black/40 bg-slate-800/30">
                    <img 
                      src="/Founder.png" 
                      alt="MOHAMMAD MIRAN KHAN — Founder & CEO of Growlanzo"
                      className="w-full h-full object-contain"
                      loading="lazy"
                    />
                  </div>
                </div>
              </div>

              {/* Founder Info — Right Side */}
              <div className="lg:col-span-3 space-y-5 text-center lg:text-left">
                <div className="space-y-1.5">
                  <span className="inline-flex items-center gap-3 px-2.5 py-0.5 bg-emerald-500/15 text-emerald-300 font-bold rounded-full border border-emerald-500/25 text-xs uppercase tracking-[0.15em]">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Founder &amp; Chief Executive Officer
                  </span>
                  <h2 className="font-display text-2xl sm:text-3xl md:text-4xl font-black tracking-tight leading-[1.1] text-white">
                    MOHAMMAD MIRAN KHAN
                  </h2>
                  <p className="text-base sm:text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                    Founder &amp; CEO Of Growlanzo
                  </p>
                </div>

                {/* Divider */}
                <div className="w-12 h-0.5 bg-gradient-to-r from-emerald-500/60 to-transparent mx-auto lg:mx-0" />

                {/* Bio */}
                <div className="space-y-3 max-w-xl">
                  <p className="text-slate-300 text-sm leading-relaxed">
                    A visionary entrepreneur with a deep passion for reshaping the future of professional work. 
                    Mohammad identified the critical gaps in traditional freelancing platforms — fragmented communication, 
                    payment insecurity, and disconnected workflows — and set out to build something better.
                  </p>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    Under his leadership, Growlanzo has emerged as a groundbreaking platform that combines 
                    <span className="text-slate-200 font-semibold"> AI-powered semantic matching</span>, 
                    <span className="text-slate-200 font-semibold"> real-time collaborative workspaces</span>, and 
                    <span className="text-slate-200 font-semibold"> escrow-backed payment protection</span> — 
                    delivering a unified experience where clients and freelancers can truly thrive together.
                  </p>
                </div>

                {/* Founder Quote */}
                <div className="relative pl-5 border-l-2 border-emerald-500/40 py-1 max-w-lg mx-auto lg:mx-0">
                  <Quote className="absolute -top-2 -left-1.5 w-4 h-4 text-emerald-500/30" fill="currentColor" />
                  <p className="text-xs text-slate-400 italic leading-relaxed">
                    "We're not just building a marketplace — we're engineering the infrastructure for the future of work. 
                    Every feature at Growlanzo is designed with one question in mind: does this make collaboration 
                    simpler, safer, and more human?"
                  </p>
                </div>

                {/* Signature Area */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-1">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white font-bold text-xs shadow-lg shadow-emerald-500/20 shrink-0">
                      MM
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-white leading-tight">MOHAMMAD MIRAN KHAN</p>
                      <p className="text-xs text-slate-500 uppercase tracking-widest">Founder &amp; CEO, Growlanzo</p>
                    </div>
                  </div>
                  <div className="flex items-center sm:ml-auto">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-white/5 rounded-lg border border-white/10">
                      <Zap className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-xs font-semibold text-slate-300">Vision-Driven</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Grid */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 mt-28">
        <div className="text-center space-y-3 mb-16">
          <span className="text-xs font-black uppercase text-emerald-600 tracking-widest">Platform Core Values</span>
          <h2 className="font-display text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            How we coordinate success
          </h2>
          <p className="text-slate-500 text-sm max-w-md mx-auto">
            These values steer every line of code we write, every AI recommendation we generate, and every contract milestone we secure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {values.map((val, index) => {
            const Icon = val.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-[2rem] p-4 border border-slate-200/50 shadow-sm flex flex-col sm:flex-row gap-3 transition-all duration-300 hover:shadow-md hover:border-emerald-500/20 group"
              >
                <div className={`h-14 w-14 rounded-xl flex items-center justify-center shrink-0 ${val.iconColor} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-7 h-7" />
                </div>
                <div className="space-y-4">
                  <h3 className="font-display font-extrabold text-lg text-slate-900 group-hover:text-emerald-700 transition-colors">
                    {val.title}
                  </h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    {val.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA Join Mission */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 2xl:px-12 mt-28">
        <div className="bg-emerald-600 rounded-[3rem] p-4 sm:p-14 text-center text-white relative overflow-hidden shadow-xl shadow-emerald-950/20">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/20 rounded-full blur-2xl -mr-16 -mt-16"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-teal-500/10 rounded-full blur-2xl -ml-16 -mb-16"></div>

          <div className="relative max-w-xl mx-auto space-y-3">
            <h2 className="font-display text-3xl sm:text-4xl font-black tracking-tight leading-none">
              Ready to experience modern co-working?
            </h2>
            <p className="text-emerald-100 text-sm leading-relaxed max-w-md mx-auto">
              Join the clients and freelancers bridging dashboard gaps and securing their contracts through active escrow.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                to="/signup"
                className="w-full sm:w-auto inline-flex h-12 px-8 items-center justify-center font-bold bg-white text-emerald-600 rounded-xl hover:bg-emerald-50 transition-all active:scale-95 shadow-md shadow-emerald-950/20"
              >
                Sign Up Free
              </Link>
              {/* Internships ship behind VITE_FEATURE_INTERNSHIPS_ENABLED — the
                  CTA must not promise a page this release may not have. */}
              {isFeatureEnabled('internships') && (
                <Link
                  to="/internships"
                  className="w-full sm:w-auto inline-flex h-12 px-6 items-center justify-center font-bold text-white border border-white/30 rounded-xl hover:bg-white/10 transition-all"
                >
                  View Internships <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
